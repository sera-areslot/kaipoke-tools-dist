// 拡張機能からOpenAIを直接呼ぶ(中継サーバーなし)。
// APIキー・モデルは設定画面で入力され、chrome.storage.local に保存される(端末内のみ)。
import { SYSTEM_PROMPT, buildUserPrompt, SYSTEM_VITALS, buildVitalsUserPrompt, composeScenario } from "./prompt.js";

const OPENAI_URL = "https://api.openai.com/v1/chat/completions";
const MAPS_DM_URL = "https://maps.googleapis.com/maps/api/distancematrix/json";
const DEFAULT_MODEL = "gpt-4o-mini";
const SOAP_RETENTION_DAYS = 90; // 揺らぎ用 soapHistory の端末保持上限(panel.js と一致させる)

// ツールバーアイコンのクリックでサイドパネルを開く
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});

// ===== 更新直後の「差し替えたのに反映されない」を自己修復する =====
// unpacked(開発者モード)拡張は、更新ツールが extension フォルダを差し替えて Chrome を開き直しても、
// Service Worker の登録やコードキャッシュが前の版のまま残ることがある(＝フロントは新・バックは旧で不一致。
// PC再起動でも直らず、chrome://extensions の「↻ 再読み込み」でのみ直る)。
// その再読み込みボタンに相当するのが chrome.runtime.reload()。ディスク上(=差し替えた実体)の版と、
// いま読み込まれている版がズレているときだけ自動で押す。反映済みなら何もしない(＝ループしない)。
function cmpVer(a, b) {
  const pa = String(a).split("."), pb = String(b).split(".");
  const n = Math.max(pa.length, pb.length);
  for (let i = 0; i < n; i++) {
    const d = (parseInt(pa[i], 10) || 0) - (parseInt(pb[i], 10) || 0);
    if (d !== 0) return d > 0 ? 1 : -1;
  }
  return 0;
}
let staleChecked = false; // Service Worker 1起動につき1回だけ確認する
async function selfHealIfStale() {
  if (staleChecked) return;
  staleChecked = true;
  try {
    const loaded = chrome.runtime.getManifest().version;               // いま実行中の版
    const res = await fetch(chrome.runtime.getURL("manifest.json"), { cache: "no-store" });
    if (!res.ok) return;
    const disk = (await res.json())?.version;                          // ディスク上の実体の版
    if (!disk || cmpVer(disk, loaded) <= 0) return;                    // 反映済み/取得失敗 → 何もしない
    const g = await chrome.storage.session.get("healReloadedFor");     // 同じ版で二重に reload しない保険
    if (g.healReloadedFor === disk) return;
    await chrome.storage.session.set({ healReloadedFor: disk });
    chrome.runtime.reload();                                           // ＝chrome://extensions の再読み込み
  } catch { /* 取得不可などは従来どおり(手動再読み込みにフォールバック) */ }
}
// SW が起動するたび(＝更新ツールが Chrome を開き直した直後や、イベントで叩き起こされた時)に確認する。
chrome.runtime.onStartup.addListener(() => { selfHealIfStale(); });
selfHealIfStale();

// 配布時に seed/patients.json を同梱しておくと、導入(インストール/更新)時に自動で取り込む。
// 利用者の手動インポートを不要にするための仕組み。属性のみマージし、既存 soapHistory は保持。
const SEED_FIELDS = ["name", "gender", "birth", "diagnosis", "care", "address"];
chrome.runtime.onInstalled.addListener(() => { seedFromBundle(); });

async function seedFromBundle() {
  let data;
  try {
    const res = await fetch(chrome.runtime.getURL("seed/patients.json"));
    if (!res.ok) return;
    data = await res.json();
  } catch { return; } // seed 未同梱なら何もしない
  if (!data || data.type !== "kaipoke-record-assist-patients" || !data.patients) return;
  // 古いスナップショットの自動投入を防ぐ(書き出しから90日超のseedはスキップ。設定画面の手動読み込みは制限しない)
  const SEED_MAX_AGE_DAYS = 90;
  const exportedMs = Date.parse(data.exportedAt || "");
  if (!isNaN(exportedMs) && Date.now() - exportedMs > SEED_MAX_AGE_DAYS * 24 * 60 * 60 * 1000) return;
  const ids = Object.keys(data.patients);
  if (!ids.length) return;
  const stamp = String(data.exportedAt || data.version || "1");
  const store = await chrome.storage.local.get(["patients", "seedStamp"]);
  if (store.seedStamp === stamp) return; // この同梱データは取込済み
  const merged = store.patients || {};
  ids.forEach((uid) => {
    const inc = data.patients[uid] || {};
    const clean = {};
    SEED_FIELDS.forEach((k) => { if (inc[k] != null && inc[k] !== "") clean[k] = String(inc[k]); });
    if (!Object.keys(clean).length) return;
    merged[uid] = Object.assign({}, merged[uid] || {}, clean, { importedAt: Date.now() });
  });
  await chrome.storage.local.set({ patients: merged, seedStamp: stamp });
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type === "GENERATE") {
    generateSoap(msg.payload).then(sendResponse);
    return true;
  }
  if (msg?.type === "GENERATE_VITALS") {
    generateVitals(msg.payload).then(sendResponse);
    return true;
  }
  if (msg?.type === "GET_TRAVEL_TIME") {
    getTravelTime(msg.from, msg.to).then(sendResponse);
    return true;
  }
  if (msg?.type === "PICK_SCENARIO") {
    pickScenarioOnly(msg.payload).then(sendResponse);
    return true;
  }
});

// 実測バイタルがある状態でも「本日の様子」だけ使いたい場合の合成(バイタル生成はしない)。
// パネルで選択された選択肢を合成するだけで、抽選も履歴も使わない。
async function pickScenarioOnly(payload) {
  const record = payload?.record;
  if (!record || typeof record !== "object") return { ok: false, error: "record がありません" };
  const scenario = composeScenario(record, sanitizeKeys(payload?.selectedScenarios));
  return { ok: true, scenario: scenario ? { keys: scenario.keys, label: scenario.label, cond: scenario.cond } : null };
}

// パネルから渡される選択(key配列)を文字列配列に正規化する。未指定・空は null＝選択なし。
function sanitizeKeys(v) {
  if (!Array.isArray(v) || !v.length) return null;
  return v.map(String);
}

// ===== 訪問間の車移動時間(Google Maps Distance Matrix) =====
// 住所ペア単位で chrome.storage.local.travelCache にキャッシュし、初回のみAPIを呼ぶ。
// 住所は変わらないため恒久キャッシュ(設定画面でクリア可能)。{ok, sec, text, cached} を返す。
function normAddr(s) {
  return String(s || "").replace(/\s+/g, " ").trim();
}

function mapsTopError(status, message) {
  if (status === "REQUEST_DENIED") {
    return "Google Maps APIキーが拒否されました。キーの有効化(Distance Matrix API)・課金設定・キー制限を設定画面/Google Cloudで確認してください。" + (message ? `（${message}）` : "");
  }
  if (status === "OVER_QUERY_LIMIT") return "Google Mapsの利用上限に達しました。時間をおくか、Google Cloud側の上限・課金を確認してください。";
  if (status === "INVALID_REQUEST") return "リクエストが不正です（住所が空の可能性）。";
  return `移動時間を取得できませんでした（${status || "不明なエラー"}）` + (message ? `: ${message}` : "");
}

function mapsElemError(status) {
  if (status === "NOT_FOUND" || status === "ZERO_RESULTS") {
    return "住所から経路を特定できませんでした。住所表記をご確認ください。";
  }
  return `区間の移動時間を取得できませんでした（${status || "不明"}）`;
}

async function getTravelTime(from, to) {
  from = normAddr(from);
  to = normAddr(to);
  if (!from || !to) return { ok: false, error: "住所が不足しています。" };
  if (from === to) return { ok: true, sec: 0, text: "0分", cached: true };

  const key = from + "||" + to;
  const store = await chrome.storage.local.get(["travelCache", "mapsApiKey"]);
  const cache = store.travelCache || {};
  const hit = cache[key];
  if (hit && typeof hit.sec === "number") return { ok: true, sec: hit.sec, text: hit.text, cached: true };

  const apiKey = store.mapsApiKey;
  if (!apiKey) return { ok: false, error: "Google Maps APIキーが未設定です。設定画面で入力してください。", needKey: true };

  const url =
    `${MAPS_DM_URL}?origins=${encodeURIComponent(from)}` +
    `&destinations=${encodeURIComponent(to)}&mode=driving&language=ja&region=jp` +
    `&key=${encodeURIComponent(apiKey)}`;
  let res;
  try {
    res = await fetch(url);
  } catch (e) {
    return { ok: false, error: `Google Mapsに接続できません(${e.message})` };
  }
  let data = {};
  try { data = await res.json(); } catch {}
  if (data.status !== "OK") {
    return { ok: false, error: mapsTopError(data.status, data.error_message), needKey: data.status === "REQUEST_DENIED" };
  }
  const el = data.rows && data.rows[0] && data.rows[0].elements && data.rows[0].elements[0];
  if (!el || el.status !== "OK" || !el.duration) {
    return { ok: false, error: mapsElemError(el && el.status) };
  }
  const sec = el.duration.value;
  const text = el.duration.text;
  cache[key] = { sec, text, at: Date.now() };
  await chrome.storage.local.set({ travelCache: cache });
  return { ok: true, sec, text, cached: false };
}

// OpenAI Chat Completions を呼ぶ共通処理。{ok, text, usage} を返す。
async function callOpenAI(system, user, maxTokens, temperature) {
  const { openaiKey, model } = await chrome.storage.local.get(["openaiKey", "model"]);
  if (!openaiKey) {
    return { ok: false, error: "OpenAI APIキーが未設定です。拡張機能の設定画面でキーを入力してください。" };
  }
  const body = {
    model: model || DEFAULT_MODEL,
    max_tokens: maxTokens,
    messages: [
      { role: "system", content: system },
      { role: "user", content: user },
    ],
  };
  if (temperature != null) body.temperature = temperature;
  let res;
  try {
    res = await fetch(OPENAI_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${openaiKey}` },
      body: JSON.stringify(body),
    });
  } catch (e) {
    return { ok: false, error: `OpenAIに接続できません(${e.message})` };
  }
  if (!res.ok) {
    // エラー本文は一度しか読めないので先に解析(メッセージ＋コード/種別)
    let detail = "", code = "";
    try {
      const e = (await res.json())?.error || {};
      detail = e.message || "";
      code = e.code || e.type || "";
    } catch {}
    if (res.status === 401) return { ok: false, error: "APIキーが無効です。設定画面で確認してください。" };
    // クレジット残高/利用上限の枯渇。OpenAIは 429(insufficient_quota) で返す。
    if (code === "insufficient_quota" || /quota|insufficient_quota|billing|exceeded your current quota/i.test(detail)) {
      return { ok: false, error: "OpenAIの利用枠が不足しています（クレジット残高または利用上限）。OpenAIの請求(Billing)画面で残高・上限を確認し、チャージしてください。" };
    }
    if (res.status === 429) return { ok: false, error: "アクセスが集中しています。少し待って再試行してください。" };
    return { ok: false, error: `生成に失敗しました(${res.status})${detail ? ": " + detail : ""}` };
  }
  let data = {};
  try { data = await res.json(); } catch {}
  const text = (data.choices && data.choices[0] && data.choices[0].message
    ? String(data.choices[0].message.content || "")
    : "").trim();
  if (!text) return { ok: false, error: "文章を生成できませんでした。入力内容を見直してください。" };
  const usage = data.usage
    ? { input_tokens: data.usage.prompt_tokens, output_tokens: data.usage.completion_tokens }
    : undefined;
  return { ok: true, text, usage };
}

// soapHistory(揺らぎ用)を {text, at} に正規化し、保持期間(90日)内のものだけ残す。
// 旧形式(文字列)は now を付与して移行。利用者の属性は対象外(保持)。
function pruneSoapHistory(arr) {
  const cutoff = Date.now() - SOAP_RETENTION_DAYS * 24 * 60 * 60 * 1000;
  return (Array.isArray(arr) ? arr : [])
    .map((e) =>
      e && typeof e === "object" && typeof e.text === "string"
        ? { text: e.text, at: Number(e.at) || Date.now() }
        : { text: String(e || ""), at: Date.now() }
    )
    .filter((e) => e.text && e.at >= cutoff);
}

// SOAP出力の整形: 体言止め・句読点なしを担保するため、生成文から句読点(。、，．)と行末空白を除去する。
function tidySoap(text) {
  return String(text || "")
    .split("\n")
    .map((line) => line.replace(/[。、，．]/g, "").replace(/[ \t　]+$/g, ""))
    .join("\n")
    .trim();
}

async function generateSoap(payload) {
  const record = payload?.record;
  if (!record || typeof record !== "object") return { ok: false, error: "record がありません" };
  const supplement = typeof payload?.supplement === "string" ? payload.supplement.slice(0, 2000) : "";

  // 重複回避の参考(揺らぎ): 反映済み(soapHistory)＋直近の生成(genHistory)の両方を渡す。
  // これにより、再生成や未反映の生成でも同じ文言が繰り返されにくくなる。
  let priorSoaps = [];
  const uid = payload?.uid;
  let store = {};
  if (uid) {
    store = await chrome.storage.local.get(["patients", "genHistory"]);
    const inserted = pruneSoapHistory(store.patients && store.patients[uid] && store.patients[uid].soapHistory).map((e) => e.text);
    const generated = (store.genHistory && store.genHistory[uid]) || [];
    priorSoaps = dedupeTexts(inserted.concat(generated)).slice(-8);
  }
  // 本日の様子(パネルで選択された選択肢)を再合成してSOAPにも反映し、バイタル生成と整合させる
  const scenario = composeScenario(record, sanitizeKeys(payload?.scenario?.keys));

  // 本日の着眼点はパネルで単一選択された文字列をそのまま使う(未選択なら指定なし。抽選しない)
  const focus = typeof payload?.focus === "string" && payload.focus ? payload.focus : null;

  // 温度を高めて言い回しに変化を出す(揺らぎ)
  const r = await callOpenAI(SYSTEM_PROMPT, buildUserPrompt(record, supplement, priorSoaps, scenario, focus), 400, 1.0);
  if (r.ok) {
    r.text = tidySoap(r.text); // 体言止め・句読点なしを担保
    // 生成結果を直近の生成履歴に記録(次回・再生成での重複回避に使う)
    if (uid && r.text) {
      const gh = store.genHistory || {};
      gh[uid] = (gh[uid] || []).concat(r.text).slice(-6);
      await chrome.storage.local.set({ genHistory: gh });
    }
  }
  return r;
}

// 重複テキストを除去して順序を保つ(空は除外)。
function dedupeTexts(arr) {
  const seen = new Set();
  const out = [];
  (arr || []).forEach((t) => {
    const k = String(t || "").trim();
    if (k && !seen.has(k)) { seen.add(k); out.push(k); }
  });
  return out;
}

// 学習用: バイタル仮値を生成して {ok, vitals:{temp,bpHigh,bpLow,pulse}, scenario} を返す。
async function generateVitals(payload) {
  const record = payload?.record;
  if (!record || typeof record !== "object") return { ok: false, error: "record がありません" };
  const uid = payload?.uid;

  // 本日の様子(パネルで選択された選択肢)を合成。未選択なら null＝様子なしで生成する。
  const scenario = composeScenario(record, sanitizeKeys(payload?.selectedScenarios));

  const r = await callOpenAI(SYSTEM_VITALS, buildVitalsUserPrompt(record, payload?.bias, scenario), 200);
  if (!r.ok) return r;
  try {
    const vitals = parseVitals(r.text);
    // LLMは同じ値に寄りやすいので、前回(同一利用者)と一定以上変わるようコードで揺らす。
    let last = {};
    if (uid) {
      const o = await chrome.storage.local.get("lastVitals");
      last = (o.lastVitals && o.lastVitals[uid]) || {};
    }
    vitals.temp = jitterTemp(vitals.temp, last.temp);
    vitals.bpHigh = jitterInt(vitals.bpHigh, last.bpHigh, [-6, -4, -2, 2, 4, 6], 80, 220);
    vitals.bpLow = jitterInt(vitals.bpLow, last.bpLow, [-4, -2, 2, 4], 40, 130);
    vitals.pulse = jitterInt(vitals.pulse, last.pulse, [-4, -2, 2, 4], 40, 130);
    ensureBpOrder(vitals); // 収縮期 > 拡張期 を保つ
    // 血圧の下(拡張期)と脈拍は同値にしない(コードで最終保証)
    if (String(vitals.bpLow) === String(vitals.pulse)) {
      const p = parseInt(vitals.pulse, 10);
      if (!isNaN(p)) vitals.pulse = String(p <= 120 ? p + 2 : p - 2);
    }
    if (uid) {
      const o = await chrome.storage.local.get("lastVitals");
      const lv = o.lastVitals || {};
      lv[uid] = { temp: vitals.temp, bpHigh: vitals.bpHigh, bpLow: vitals.bpLow, pulse: vitals.pulse };
      await chrome.storage.local.set({ lastVitals: lv });
    }
    return { ok: true, vitals, scenario: scenario ? { keys: scenario.keys, label: scenario.label, cond: scenario.cond } : null };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

// 体温に日々の揺れ(±0.1〜0.2)を加え、前回値とは0.1以上変える。生理的範囲にクランプ。
function round1(x) { return Math.round(x * 10) / 10; }
function jitterTemp(tempStr, lastTemp) {
  const base = parseFloat(tempStr);
  if (isNaN(base)) return tempStr; // 数値でなければそのまま
  let cands = [-0.2, -0.1, 0.1, 0.2].map((d) => round1(base + d)); // 必ず基準値から0.1以上動かす
  const last = parseFloat(lastTemp);
  if (!isNaN(last)) {
    const f = cands.filter((v) => Math.abs(v - last) >= 0.099); // 前回と0.1以上離れる候補のみ
    if (f.length) cands = f;
  }
  let t = cands[Math.floor(Math.random() * cands.length)];
  t = Math.min(41.0, Math.max(35.0, t)); // 生理的サニティ
  return t.toFixed(1);
}

// 整数バイタル(血圧・脈拍)を steps の幅で揺らし、前回値とは最小ステップ以上変える。範囲にクランプ。
function jitterInt(valStr, lastVal, steps, min, max) {
  const base = parseInt(valStr, 10);
  if (isNaN(base)) return valStr; // 数値でなければそのまま
  const minStep = Math.min.apply(null, steps.map(Math.abs));
  let cands = steps.map((d) => base + d); // 必ず基準値から minStep 以上動かす
  const last = parseInt(lastVal, 10);
  if (!isNaN(last)) {
    const f = cands.filter((v) => Math.abs(v - last) >= minStep); // 前回と minStep 以上離れる候補のみ
    if (f.length) cands = f;
  }
  let v = cands[Math.floor(Math.random() * cands.length)];
  v = Math.min(max, Math.max(min, v));
  return String(v);
}

// 収縮期 > 拡張期 を保つ(最低差20mmHg)。揺らしで逆転/近接したら収縮期を上げる。
function ensureBpOrder(vitals) {
  const hi = parseInt(vitals.bpHigh, 10);
  const lo = parseInt(vitals.bpLow, 10);
  if (!isNaN(hi) && !isNaN(lo) && hi - lo < 20) vitals.bpHigh = String(lo + 20);
}

function parseVitals(text) {
  let t = String(text || "").trim().replace(/^```(json)?/i, "").replace(/```$/, "").trim();
  let obj = null;
  try { obj = JSON.parse(t); }
  catch {
    const i = t.indexOf("{"), j = t.lastIndexOf("}");
    if (i >= 0 && j > i) { try { obj = JSON.parse(t.slice(i, j + 1)); } catch {} }
  }
  if (!obj || typeof obj !== "object") throw new Error("バイタル(JSON)を解析できませんでした");
  const num = (k) => String(obj[k] == null ? "" : obj[k]).replace(/[^0-9.]/g, "");
  return { temp: num("temp"), bpHigh: num("bpHigh"), bpLow: num("bpLow"), pulse: num("pulse") };
}
