// サイドパネル: 画面読取 + 取り込み済み利用者属性 → 観察記録(SOAP)生成 → 反映
import { SCENARIOS, AXES, eligibleScenarios, focusCandidates } from "../prompt.js";

const $ = (id) => document.getElementById(id);

let lastData = null;   // 記録書Ⅱ画面の読取結果
let patient = null;    // 取り込み済み属性(userInternalIdでキャッシュからLookup)
let focusChipsUid = null; // 着眼点チップを構築済みの利用者ID(利用者が変わったときだけ再構築する)

const SOAP_RETENTION_DAYS = 90; // SOAP履歴(揺らぎ用)の端末保持上限。利用者属性は対象外(保持)
let sweptThisSession = false;   // 期限切れSOAPの掃除はパネル表示中に1回だけ実行
let schedResultSig = null;      // 表示中の移動チェック結果が対象とする日付/内容の指紋。日付変更の検知に使う

// 更新通知: 配布元の latest.json を見て、現行より新しければパネル上部に案内を出す。
// ホスティング先を変えたら、下記URLと manifest.json の host_permissions を合わせて変更する。
const UPDATE_MANIFEST_URL = "https://raw.githubusercontent.com/sera-areslot/kaipoke-tools-dist/main/latest.json";
const UPDATE_CHECK_INTERVAL_MS = 6 * 60 * 60 * 1000; // 6時間に1回まで確認

// 動作中のバージョンをヘッダに表示（manifestから取得＝実際に読み込まれている版）。
// 更新.bat 実行後に「Chromeを開き直したか」を利用者自身が確認できるようにする。
$("appVersion").textContent = "v" + chrome.runtime.getManifest().version;

selfHealIfStale(); // 更新直後にフロント/バックエンドの版がズレていたら自動で再読み込みして直す
init();
checkForUpdate();
$("retryBtn").addEventListener("click", init);
$("reloadBtn").addEventListener("click", refresh);
$("generateBtn").addEventListener("click", generate);
$("insertBtn").addEventListener("click", insert);
$("checkScheduleBtn").addEventListener("click", checkSchedule);
$("openOptions").addEventListener("click", () => chrome.runtime.openOptionsPage());

// ===== セグメント/チップ共通の選択UI =====
// .seg(単一選択)はクリックで .on を付け替え、.chips.single(単一トグル)は再クリックで解除、
// .chips(複数選択)はトグルする。
document.addEventListener("click", (e) => {
  const btn = e.target.closest(".seg > button, .chips > button");
  if (!btn || btn.disabled || btn.classList.contains("locked")) return;
  const group = btn.parentElement;
  if (group.classList.contains("seg")) {
    group.querySelectorAll("button").forEach((b) => {
      b.classList.toggle("on", b === btn);
      b.setAttribute("aria-pressed", String(b === btn));
    });
  } else if (group.classList.contains("single")) {
    // 単一選択。選択中を再クリックしたら「特になし」(data-value="")に戻す
    const was = btn.classList.contains("on");
    group.querySelectorAll("button").forEach((b) => b.classList.remove("on"));
    if (!was) btn.classList.add("on");
    else group.querySelector('button[data-value=""]')?.classList.add("on");
  } else {
    btn.classList.toggle("on");
  }
  group.dispatchEvent(new Event("selchange"));
});
const segValue = (id) => $(id).querySelector("button.on")?.dataset.value ?? "";

// ===== 本日の様子(軸別セグメント) =====
// 各軸の初期値は「言及なし」＝その話題を記録に書かない。抽選はしない。
// 体調以外の選択(counted)は同時2つまで。3つ目を選ぶと最も古い選択が自動で解除される。
// 選択は保存しない(パネル読込・利用者切替で全て言及なしに戻る)。
const byKey = new Map(SCENARIOS.map((s) => [s.key, s]));
let contentOrder = []; // counted(体調以外)の選択キー。古い順(FIFO)
let axesSel = {};      // 軸id -> 選択中key(セグメント軸のみ。selchangeの差分検出用)

renderAxes();
// 旧仕様(抽選・チップ絞り込み)の保存データは使わなくなったため一度だけ掃除する
chrome.storage.local.remove(["scenarioChipSel", "scenarioHistory", "focusHistory"]);

function renderAxes() {
  const root = $("scenarioAxes");
  root.textContent = "";
  contentOrder = [];
  axesSel = {};
  AXES.forEach((axis) => {
    const row = document.createElement("div");
    row.className = "axisRow";
    const lab = document.createElement("span");
    lab.className = "segLabel";
    lab.textContent = axis.label;
    const group = document.createElement("div");
    group.className = axis.type === "seg" ? "seg" : "chips";
    group.dataset.axis = axis.id;
    if (axis.type === "seg") {
      const none = document.createElement("button");
      none.type = "button";
      none.dataset.value = "";
      none.textContent = "言及なし";
      none.classList.add("on", "default");
      group.appendChild(none);
    }
    axis.options.forEach((key) => {
      const s = byKey.get(key);
      const b = document.createElement("button");
      b.type = "button";
      b.dataset.value = key;
      b.textContent = s.chip || s.label;
      b.title = s.label;
      group.appendChild(b);
    });
    group.addEventListener("selchange", () => onAxisChange(axis, group));
    row.appendChild(lab);
    row.appendChild(group);
    root.appendChild(row);
  });
}

function onAxisChange(axis, group) {
  if (axis.type === "seg") {
    const prev = axesSel[axis.id] || "";
    const cur = group.querySelector("button.on")?.dataset.value || "";
    axesSel[axis.id] = cur;
    if (axis.counted) {
      if (prev) contentOrder = contentOrder.filter((k) => k !== prev);
      if (cur) contentOrder.push(cur);
    }
  } else {
    // chips: 現在のON集合との差分で追加/削除を検出する
    const cur = new Set([...group.querySelectorAll("button.on")].map((b) => b.dataset.value));
    contentOrder = contentOrder.filter((k) => !axis.options.includes(k) || cur.has(k));
    cur.forEach((k) => { if (!contentOrder.includes(k)) contentOrder.push(k); });
  }
  while (contentOrder.length > 2) deselectKey(contentOrder.shift()); // 最古を自動解除
}

// 指定キーの選択を解除する。selchange は発火させない(FIFO処理からの再帰を防ぐ)。
function deselectKey(key) {
  const btn = $("scenarioAxes").querySelector(`button[data-value="${key}"]`);
  if (!btn) return;
  const group = btn.parentElement;
  if (group.classList.contains("seg")) {
    group.querySelectorAll("button").forEach((b) => {
      const on = b.dataset.value === "";
      b.classList.toggle("on", on);
      b.setAttribute("aria-pressed", String(on));
    });
    axesSel[group.dataset.axis] = "";
  } else {
    btn.classList.remove("on");
  }
}

// 生成に渡す選択キー(体調＋内容2つまで)
function selectedScenarioKeys() {
  const cond = axesSel["axisCond"] || "";
  return (cond ? [cond] : []).concat(contentOrder);
}

// 利用者の状態に合わない選択肢は表示したまま選択不可(減光)にする(選択中なら解除)。
// disabled属性だとホバーが拾えないため .locked クラスで表現し、
// ホバー時に data-lock の簡潔な理由をCSSツールチップ(赤文字)で表示する。
// 「言及なし」は常に選択可能。
function updateScenarioEligibility() {
  const ok = new Set(eligibleScenarios(apiRecordSafe()).map((s) => s.key));
  $("scenarioAxes").querySelectorAll("[data-axis]").forEach((group) => {
    group.querySelectorAll("button").forEach((b) => {
      const key = b.dataset.value;
      if (!key) return; // 言及なし
      const dis = !ok.has(key);
      const s = byKey.get(key);
      b.classList.toggle("locked", dis);
      b.setAttribute("aria-disabled", String(dis));
      if (dis) {
        b.dataset.lock = s?.lock || "選択できません";
        b.removeAttribute("title"); // ブラウザ標準ツールチップと二重にしない
      } else {
        delete b.dataset.lock;
        b.title = s?.label || "";
      }
      if (dis && b.classList.contains("on")) {
        deselectKey(key);
        contentOrder = contentOrder.filter((k) => k !== key);
        if (axesSel[group.dataset.axis] === key) axesSel[group.dataset.axis] = "";
      }
    });
  });
}

// 本日の着眼点チップ(単一選択・初期値「特になし」)。候補が利用者(傷病名)に依存するため、
// 利用者が変わったときだけ再構築する。選択は保存しない(利用者切替で特になしに戻る)。
function renderFocusChips() {
  const uid = lastData?.userInternalId || null;
  if (uid === focusChipsUid) return;
  focusChipsUid = uid;
  const root = $("focusChips");
  root.textContent = "";
  const none = document.createElement("button");
  none.type = "button";
  none.dataset.value = "";
  none.textContent = "特になし";
  none.classList.add("on", "default");
  root.appendChild(none);
  focusCandidates(apiRecordSafe()).forEach((label) => {
    const b = document.createElement("button");
    b.type = "button";
    b.dataset.value = label;
    b.textContent = label;
    root.appendChild(b);
  });
}

// チップの適合判定・候補構築に使う最小レコード(利用者未取り込みでも空文字で機能する)
function apiRecordSafe() {
  return {
    diagnosis: patient?.diagnosis || "",
    care: patient?.care || "",
    visitDate: lastData?.visitDate || "",
  };
}

// タブ切替・ページ遷移にパネルを追従させる。
// サイドパネルはウィンドウ共通のため、追従しないと「画面はA・実タブはB」の状態になり、
// 生成結果を別の利用者へ反映してしまう(最終ガードは insert()/generate() 側にも置く)。
chrome.tabs.onActivated.addListener(() => init());
chrome.tabs.onUpdated.addListener((_tabId, changeInfo, tab) => {
  // ページ遷移/再読込(日付変更で再読込される場合を含む)では前ページの移動チェック結果を消す
  if (tab.active && changeInfo.status === "complete") { hideSchedResult(); init(); }
});

// 画面側の変更(訪問日・実測バイタル)に「この訪問」表示を追従させる軽量ポーリング。
// 同一利用者のときだけ最新化し、生成結果やステータスには触れない。
setInterval(pollPage, 1500);
setInterval(pollSchedule, 1500); // 表示中の日付/内容が変わったら、古い移動チェック結果を消して再判定を促す
async function pollPage() {
  if ($("main").classList.contains("hidden")) return; // 記録書Ⅱを表示中のときだけ
  const res = await sendToPage({ type: "EXTRACT" });
  if (!res?.ok || res.data.userInternalId !== lastData?.userInternalId) return; // 別利用者は init 側が追従
  const changed =
    res.data.visitDate !== lastData.visitDate ||
    JSON.stringify(res.data.vitals1) !== JSON.stringify(lastData.vitals1);
  if (!changed) return;
  lastData = res.data;
  renderSummary(lastData);
  updateScenarioEligibility(); // 訪問日(月)の変更で暑さ/冷えの適合が変わるため追従させる
}

// 移動チェック結果が対象とする「日付＋訪問内容」の指紋。日付や予定が変わると値が変わる。
function scheduleSig(ym, visits) {
  return (ym || "") + "|" + (visits || [])
    .map((v) => `${v.day}:${v.uid}:${v.start}:${v.staff}`)
    .sort()
    .join(",");
}

// スケジュール画面で日付/内容が変わったのに前の結果が残っている場合に消す。
// API課金のため自動で再判定はせず、ボタンでの再実行を促すだけ。
async function pollSchedule() {
  if (schedResultSig === null) return;                          // 結果未表示なら監視不要
  if ($("scheduleMain").classList.contains("hidden")) return;   // スケジュール画面表示中のみ
  const res = await sendToPage({ type: "EXTRACT_SCHEDULE" });
  if (!res?.ok) return;
  if (scheduleSig(res.ym, res.visits) === schedResultSig) return; // 変化なし
  hideSchedResult();
  setSchedStatus("表示中の日付が変わりました。「移動をチェック」で再判定してください。");
}

async function activeTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

async function sendToPage(message) {
  const tab = await activeTab();
  if (!tab?.id) return null;
  try {
    return await chrome.tabs.sendMessage(tab.id, message);
  } catch {
    return null; // 対象ページでない
  }
}

async function getPatient(uid) {
  if (!uid) return null;
  const o = await chrome.storage.local.get("patients");
  return (o.patients || {})[uid] || null;
}

async function init() {
  clearResult(); // ページ移動(タブ切替・遷移)のたびに入力/結果欄を空にする
  const ping = await sendToPage({ type: "PING" });
  const onRecord = !!(ping?.ok && ping.isRecordPage);
  const onSchedule = !!(ping?.ok && ping.isSchedulePage);
  $("main").classList.toggle("hidden", !onRecord);
  $("scheduleMain").classList.toggle("hidden", !onSchedule);
  $("guide").classList.toggle("hidden", onRecord || onSchedule);
  if (onRecord) await refresh();
  else { $("patientName").textContent = ""; lastData = null; patient = null; } // 記録書Ⅱを離れたら前の利用者の名前・状態を残さない
  if (!onSchedule) hideSchedResult(); // スケジュール以外へ移ったら結果を消す(API課金のため自動実行しない)
}

async function refresh() {
  const res = await sendToPage({ type: "EXTRACT" });
  if (!res?.ok) {
    setStatus("画面を読み取れませんでした。再読込してください。", true);
    return;
  }
  const prevUid = lastData?.userInternalId;
  lastData = res.data;
  patient = await getPatient(lastData.userInternalId);

  // 利用者が変わったら、前の利用者向けの生成結果と本日の様子の選択を破棄する(誤反映の防止)
  if (lastData.userInternalId !== prevUid) { clearResult(); renderAxes(); }

  // 期限切れSOAP履歴の掃除(パネル表示中に1回だけ。利用者属性は消さない)
  if (!sweptThisSession) { sweptThisSession = true; await sweepExpiredSoap(); }

  $("patientName").textContent = lastData.patientNameLocal
    ? `${lastData.patientNameLocal} 様`
    : "";
  renderSummary(lastData);
  renderAttrStatus(lastData, patient);
  updateScenarioEligibility();
  renderFocusChips();
  setStatus("");
}

function renderSummary(d) {
  const lines = [];
  if (d.visitDate) lines.push(`訪問日: ${d.visitDate}`);
  const v = d.vitals1 || {};
  const vit = [];
  if (v.temp) vit.push(`体温 ${v.temp}`);
  if (v.bpHigh || v.bpLow) vit.push(`血圧 ${v.bpHigh || "—"}/${v.bpLow || "—"}`);
  if (v.pulse) vit.push(`脈拍 ${v.pulse}`);
  if (vit.length) lines.push(`実測バイタル: ${vit.join(" / ")}`);
  $("summary").textContent = lines.join("\n");
}

function renderAttrStatus(d, p) {
  const el = $("attrStatus");
  if (!d.userInternalId) {
    el.innerHTML = '<span class="warn">この画面から利用者IDを取得できませんでした。</span>';
    return;
  }
  if (!p) {
    el.innerHTML =
      '<span class="warn">未取り込みです。</span>\n' +
      "基本情報ページと、ADL・看護ページで「取り込み」ボタンを押してください。";
    return;
  }
  const have = [];
  const miss = [];
  (p.gender ? have : miss).push("性別");
  (p.birth ? have : miss).push("生年月日");
  (p.diagnosis ? have : miss).push("傷病名");
  (p.care ? have : miss).push("療養状況");
  const parts = [];
  if (p.gender) parts.push(`性別: ${p.gender}`);
  if (p.birth) parts.push(`生年月日: ${p.birth}`);
  if (p.diagnosis) parts.push(`傷病名: ${p.diagnosis}`);
  if (p.care) parts.push(`療養状況: ${truncate(p.care, 80)}`);
  let txt = parts.join("\n");
  if (miss.length) txt += `\n⚠ 未取り込み: ${miss.join("・")}（該当ページで取り込み）`;
  el.textContent = txt;
}

function truncate(s, n) {
  s = String(s || "");
  return s.length > n ? s.slice(0, n) + "…" : s;
}

// バイタル生成の傾向指定(低め/おまかせ/高め)。空欄時の生成にだけ効く。
function readVitalsBias() {
  return { temp: segValue("biasTemp"), bp: segValue("biasBp"), pulse: segValue("biasPulse") };
}

// APIへ送るのは属性＋訪問日＋実測バイタルのみ（氏名は送らない）
function apiRecord(d, p) {
  const v = d.vitals1 || {};
  return {
    gender: p.gender || "",
    birth: p.birth || "",
    diagnosis: p.diagnosis || "",
    care: p.care || "",
    visitDate: d.visitDate || "",
    visitTime: d.visitTime || "", // 訪問時間(例 "11:00〜11:30")。時間帯整合のためプロンプトに渡す(未入力は"")
    vitals: { temp: v.temp || "", bpHigh: v.bpHigh || "", bpLow: v.bpLow || "", pulse: v.pulse || "" },
  };
}

// 生成結果・補足の各テキストボックスを空にする(ページ移動時・利用者変更時)
function clearResult() {
  $("supplement").value = "";
  setResultVitals(null);
  $("result").value = "";
  $("scenarioNote").textContent = "";
  $("scenarioNote").classList.add("hidden");
  $("vitalsRow").classList.add("hidden");
  $("resultSection").classList.add("hidden");
}

// 結果欄の分割バイタル入力(体温・血圧高/低・脈拍)を読み書きする。
// 反映時に {temp,bpHigh,bpLow,pulse} を画面のバイタル欄へ書き込む。
function setResultVitals(v) {
  v = v || {};
  $("rvTemp").value = v.temp || "";
  $("rvBpHigh").value = v.bpHigh || "";
  $("rvBpLow").value = v.bpLow || "";
  $("rvPulse").value = v.pulse || "";
}
function getResultVitals() {
  return {
    temp: $("rvTemp").value.trim(),
    bpHigh: $("rvBpHigh").value.trim(),
    bpLow: $("rvBpLow").value.trim(),
    pulse: $("rvPulse").value.trim(),
  };
}

async function generate() {
  await refresh();
  if (!lastData) return;
  if (!lastData.userInternalId) { setStatus("利用者IDが取得できません。", true); return; }
  if (!patient || (!patient.care && !patient.diagnosis)) {
    setStatus("利用者情報が未取り込みです。基本情報ページとADL・看護ページで取り込んでください。", true);
    return;
  }

  const btn = $("generateBtn");
  btn.disabled = true;
  btn.textContent = "生成中…";
  setStatus("");
  try {
    // 1) 実測バイタルがすべて空のときだけ仮バイタルを生成する。
    //    画面にはまだ書かず、結果欄に表示して「反映」時にまとめて書き込む。
    let vitals = null;
    let scenario = null; // 本日のシナリオ(仮バイタル生成時のみ。SOAPにも渡して内容を整合させる)
    const v0 = lastData.vitals1 || {};
    const hadMeasured = !!(v0.temp || v0.bpHigh || v0.bpLow || v0.pulse); // 画面に実測バイタルがある＝事実準拠モード
    if (!hadMeasured) {
      const vr = await chrome.runtime.sendMessage({
        type: "GENERATE_VITALS",
        payload: {
          record: apiRecord(lastData, patient),
          bias: readVitalsBias(),
          uid: lastData.userInternalId,
          selectedScenarios: selectedScenarioKeys(),
        },
      });
      if (vr?.ok) { vitals = vr.vitals; scenario = vr.scenario || null; } // 生成失敗時もSOAPは続行する
    } else if (selectedScenarioKeys().length) {
      // 実測バイタルは一切変えずに、選択された本日の様子・調子だけ合成してSOAPへ反映する
      let sr;
      try {
        sr = await chrome.runtime.sendMessage({
          type: "PICK_SCENARIO",
          payload: {
            record: apiRecord(lastData, patient),
            uid: lastData.userInternalId,
            selectedScenarios: selectedScenarioKeys(),
          },
        });
      } catch { sr = null; } // 受信側が無い＝下の無反応チェックで拾う
      // PICK_SCENARIO は v0.21.0 で追加。応答が無い＝裏側のバックグラウンド(サービスワーカー)が
      // 旧版のまま動いている状態(画面だけ更新され、裏側が古い)。Chrome再起動/拡張OFF→ONで解消する。
      if (!sr) {
        setStatus("拡張機能の再起動が必要です（バックグラウンドが古い可能性）。Chromeを完全に終了して開き直すか、chrome://extensions で当拡張をOFF→ONにしてから、もう一度お試しください。", true);
        return;
      }
      if (sr.ok) scenario = sr.scenario || null;
      else { setStatus(sr.error || "本日の様子を取得できませんでした。", true); return; }
    }

    // 2) 観察記録(SOAP)を生成。仮バイタルを作った場合は文脈にも渡す。
    const record = apiRecord(lastData, patient);
    if (vitals) {
      record.vitals = {
        temp: vitals.temp || "", bpHigh: vitals.bpHigh || "",
        bpLow: vitals.bpLow || "", pulse: vitals.pulse || "",
      };
    }
    const focus = $("focusChips").querySelector("button.on")?.dataset.value || "";
    const res = await chrome.runtime.sendMessage({
      type: "GENERATE",
      payload: {
        record,
        supplement: $("supplement").value.trim(),
        uid: lastData.userInternalId, // 揺らぎ用の履歴を引くキー(プロンプトには含めない)
        scenario: scenario ? { keys: scenario.keys } : null, // 本日の様子(選択の合成。学習用モードのみ非null)
        focus, // 本日の着眼点(単一選択。空＝指定なし)
      },
    });
    if (!res?.ok) {
      setStatus(res?.error || "生成に失敗しました", true);
      return;
    }

    // 3) 結果欄に表示(バイタルは生成したときだけ。画面へは「反映」時に書き込む)
    setResultVitals(vitals);
    $("vitalsRow").classList.toggle("hidden", !vitals);
    // 本日の様子・調子・着眼点を表示。バイタル入力欄には入れない(反映時に別扱いのため)。
    const noteParts = [];
    if (scenario) noteParts.push(`本日の様子：${scenario.label}（調子：${scenario.cond.split("（")[0]}）`);
    if (focus) noteParts.push(`着眼点：${focus}`);
    $("scenarioNote").textContent = noteParts.join("／");
    $("scenarioNote").classList.toggle("hidden", !noteParts.length);
    $("result").value = res.text;
    $("resultSection").classList.remove("hidden");
    setStatus("");
  } finally {
    btn.disabled = false;
    btn.textContent = "観察記録（SOAP）を生成";
  }
}

async function insert() {
  const text = $("result").value.trim();
  if (!text) { setStatus("反映する文章がありません", true); return; }
  const mode = "replace";

  // 反映直前に現在のタブを読み直し、生成時の利用者と一致するか検証する。
  // (生成後にタブを切り替えていると、別の利用者の記録へ書き込んでしまうため最終ガード)
  const current = await sendToPage({ type: "EXTRACT" });
  if (!current?.ok) {
    setStatus("記録書Ⅱの画面が見つかりません。対象タブを開いて『再読込』してください。", true);
    return;
  }
  const activeUid = current.data.userInternalId;
  if (!activeUid || activeUid !== lastData?.userInternalId) {
    await refresh(); // 表示を実タブに合わせ直す(利用者が変わっていれば生成結果も破棄される)
    setStatus("表示中の利用者と画面の利用者が一致しません。画面を読み直しました。生成し直してください。", true);
    return;
  }

  const existing = current.data.existingComment?.trim();
  if (mode === "replace" && existing) {
    if (!confirm("観察記録欄に既に入力があります。置き換えてよろしいですか?")) return;
  }

  // 1) バイタル(結果欄に表示中のときだけ)を画面のバイタル欄へ表示反映(表示のみ・ツールは保存しない)
  if (!$("vitalsRow").classList.contains("hidden")) {
    const v = getResultVitals();
    if (v.temp || v.bpHigh || v.bpLow || v.pulse) {
      await sendToPage({ type: "INSERT_VITALS", vitals: v });
    }
  }

  // 2) SOAPを観察記録欄へ反映
  const res = await sendToPage({ type: "INSERT", text, mode });
  if (res?.ok) {
    // 反映した内容を履歴に追記(次回生成で重複回避の参考にする)
    await appendSoapHistory(activeUid, text);
    setStatus("");
  } else {
    setStatus(res?.error || "反映に失敗しました", true);
  }
}

// soapHistory のエントリを {text, at} に正規化(旧形式の文字列は now を付与)し、
// 保持期間(90日)内のものだけ残す。利用者の属性(氏名・傷病名等)は対象外(保持)。
function pruneSoapHistory(arr) {
  const cutoff = Date.now() - SOAP_RETENTION_DAYS * 24 * 60 * 60 * 1000;
  return (Array.isArray(arr) ? arr : [])
    .map((e) =>
      e && typeof e === "object" && typeof e.text === "string"
        ? { text: e.text, at: Number(e.at) || Date.now() }
        : { text: String(e || ""), at: Date.now() }
    )
    .filter((e) => e.text && e.at >= cutoff);
}

// 全利用者の soapHistory から期限切れを削除する(属性は残す)。
// 1ユーザ/1タブ運用前提のため、パネル表示中に1回だけ await して実行し、書き込み競合を作らない。
async function sweepExpiredSoap() {
  const o = await chrome.storage.local.get("patients");
  const patients = o.patients;
  if (!patients) return;
  let changed = false;
  for (const uid of Object.keys(patients)) {
    const rec = patients[uid];
    if (!rec || !Array.isArray(rec.soapHistory) || !rec.soapHistory.length) continue;
    const pruned = pruneSoapHistory(rec.soapHistory).slice(-10);
    // 件数が減った、または旧形式(文字列/at欠落)が混じっていた場合に書き戻す
    const wasLegacy = rec.soapHistory.some(
      (e) => !e || typeof e !== "object" || typeof e.at !== "number"
    );
    if (pruned.length !== rec.soapHistory.length || wasLegacy) {
      rec.soapHistory = pruned;
      changed = true;
    }
  }
  if (changed) await chrome.storage.local.set({ patients });
}

// 同一利用者のSOAP履歴を chrome.storage に追記(期限切れ除去＋直近10件保持)
async function appendSoapHistory(uid, text) {
  if (!uid || !text) return;
  const o = await chrome.storage.local.get("patients");
  const patients = o.patients || {};
  const rec = patients[uid] || {};
  const hist = pruneSoapHistory(rec.soapHistory); // 期限切れ除去＋正規化
  hist.push({ text, at: Date.now() });
  rec.soapHistory = hist.slice(-10);
  patients[uid] = rec;
  await chrome.storage.local.set({ patients });
}

function setStatus(message, isError = false) {
  const el = $("status");
  el.textContent = message;
  el.classList.toggle("error", isError);
}

// ===== 訪問の移動チェック（月間スケジュール一覧）=====
// 画面の予定を職員×日でまとめ、連続訪問間の車移動(Google Maps)が間に合うか判定する。
// API課金のため自動実行はせず「移動をチェック」ボタンで明示実行する。

function normAddr(s) {
  return String(s || "").replace(/\s+/g, " ").trim();
}
// 住所の表記ゆれ(全角半角・ハイフン種別・空白・丁目番地号)を吸収した「同一住所」判定用キー。
// 同一宅(同居家族など)を同一住所とみなし、連続訪問の移動を0(✓)扱いにするために使う。
// ※移動時間そのものの判定(legVerdict＝移動+余裕)は別住所のまま据え置き。建物名・部屋番号が
//   異なるものは別住所として扱う(別宅を同一視しないため)。
function addrKey(s) {
  return String(s || "")
    .normalize("NFKC")                                  // 全角英数/全角空白/全角ハイフンを半角化
    .replace(/[‐-―−ーｰ]/g, "-") // 各種ハイフン/ダッシュ/長音をハイフンへ
    .replace(/[丁目番地号]/g, "-")                       // 丁目/番地/番/号 をハイフンへ
    .replace(/\s+/g, "")                                // 空白を除去
    .replace(/-+/g, "-")                                // 連続ハイフンを1つに
    .replace(/^-+|-+$/g, "")                            // 前後のハイフンを除去
    .toLowerCase();
}
function toMin(t) {
  const m = String(t || "").match(/(\d{1,2}):(\d{2})/);
  return m ? Number(m[1]) * 60 + Number(m[2]) : null;
}
function secToMin(sec) {
  return Math.round(Number(sec || 0) / 60);
}
// ym "202605" + day "18" -> "5/18"
function ymdLabel(ym, day) {
  const mo = ym && ym.length >= 6 ? String(Number(ym.slice(4, 6))) : "";
  return mo ? `${mo}/${day}` : `${day}日`;
}

// ===== 更新通知（配布URLの latest.json と現行バージョンを比較して案内） =====
function cmpVer(a, b) {
  const pa = String(a).split("."), pb = String(b).split(".");
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (parseInt(pa[i], 10) || 0) - (parseInt(pb[i], 10) || 0);
    if (d !== 0) return d > 0 ? 1 : -1;
  }
  return 0;
}

// 更新直後の「差し替えたのに反映されない(フロントは新・バックは旧で不一致)」を自己修復する。
// unpacked拡張は、更新ツールが extension を差し替えて Chrome を開き直しても、Service Worker の登録や
// コードキャッシュが前の版のまま残ることがある(PC再起動でも直らず、chrome://extensions の「↻ 再読み込み」
// でのみ直る)。その再読み込みボタンに相当する chrome.runtime.reload() を、ディスク上(=差し替えた実体)の版と
// いま読み込まれている版がズレているときだけ自動で押す。反映済みなら何もしない(＝ループしない)。
async function selfHealIfStale() {
  try {
    const loaded = chrome.runtime.getManifest().version;               // いま読み込まれている版
    const res = await fetch(chrome.runtime.getURL("manifest.json"), { cache: "no-store" });
    if (!res.ok) return;
    const disk = (await res.json())?.version;                          // ディスク上の実体の版
    if (!disk || cmpVer(disk, loaded) <= 0) return;                    // 反映済み/取得失敗 → 何もしない
    const g = await chrome.storage.session.get("healReloadedFor");     // 同じ版で二重に reload しない保険
    if (g.healReloadedFor === disk) return;
    await chrome.storage.session.set({ healReloadedFor: disk });
    chrome.runtime.reload();                                           // ＝chrome://extensions の再読み込み
  } catch { /* 取得不可などは従来どおり(更新バナー/手動再読み込みにフォールバック) */ }
}

async function checkForUpdate() {
  try {
    if (!UPDATE_MANIFEST_URL || UPDATE_MANIFEST_URL.includes("<")) return; // 未設定なら何もしない
    const cur = chrome.runtime.getManifest().version;
    const o = await chrome.storage.local.get("lastUpdateCheckAt");
    if (o.lastUpdateCheckAt && Date.now() - o.lastUpdateCheckAt < UPDATE_CHECK_INTERVAL_MS) return;
    await chrome.storage.local.set({ lastUpdateCheckAt: Date.now() }); // 失敗しても再連打しない
    const res = await fetch(UPDATE_MANIFEST_URL, { cache: "no-store" });
    if (!res.ok) return;
    const meta = await res.json();
    if (meta && meta.version && cmpVer(meta.version, cur) > 0) showUpdateBanner(meta.version, meta.notes);
  } catch { /* オフライン・未配布などは無視 */ }
}

function showUpdateBanner(ver, notes) {
  if ($("updateBanner")) return;
  const b = document.createElement("div");
  b.id = "updateBanner";
  b.style.cssText = "background:#fff3cd;border-bottom:1px solid #e0c56e;color:#6b5900;padding:8px 10px;font-size:12px;line-height:1.5;";
  b.textContent = `🔔 新しいバージョン v${ver} があります。「更新ツール（更新.bat）」を実行し、Chromeを開き直してください。`;
  if (notes) {
    const n = document.createElement("div");
    n.style.cssText = "margin-top:2px;color:#8a7b3a;";
    n.textContent = "変更点: " + notes;
    b.appendChild(n);
  }
  document.body.insertBefore(b, document.body.firstChild);
}

function setSchedStatus(msg, isError = false) {
  const el = $("schedStatus");
  el.textContent = msg;
  el.classList.toggle("error", isError);
}
function hideSchedResult() {
  const r = $("schedResult");
  if (r) { r.textContent = ""; r.classList.add("hidden"); }
  schedResultSig = null;
  setSchedStatus("");
}

async function checkSchedule() {
  const btn = $("checkScheduleBtn");
  btn.disabled = true;
  hideSchedResult();
  setSchedStatus("画面を読み取り中…");
  try {
    const res = await sendToPage({ type: "EXTRACT_SCHEDULE" });
    if (!res?.ok) {
      setSchedStatus("スケジュールを読み取れませんでした。ページを再読込してください。", true);
      return;
    }
    const visits = res.visits || [];
    if (!visits.length) {
      setSchedStatus("予定（サービス）が見つかりませんでした。", true);
      return;
    }

    const store = await chrome.storage.local.get(["patients", "bufferMin", "mapsApiKey"]);
    if (!store.mapsApiKey) {
      setSchedStatus("Google Maps APIキーが未設定です。右上の「⚙ 設定」で登録してください。", true);
      return;
    }
    const patients = store.patients || {};
    const buffer = Number.isFinite(Number(store.bufferMin)) ? Number(store.bufferMin) : 10;

    // 氏名・住所を付与（住所は patients キャッシュから。氏名は画面セル名でフォールバック）
    visits.forEach((v) => {
      const p = patients[v.uid] || {};
      v.name = p.name || v.cellName || v.uid;
      v.address = normAddr(p.address);
    });

    // 職員×日でグループ化（職員未割当は件数のみ）
    const groups = new Map();
    let unassigned = 0;
    for (const v of visits) {
      if (!v.staff) { unassigned++; continue; }
      const key = v.staff + "|" + v.day;
      if (!groups.has(key)) groups.set(key, { staff: v.staff, day: v.day, ym: v.ym, visits: [] });
      groups.get(key).visits.push(v);
    }
    for (const g of groups.values()) {
      g.visits.sort((a, b) => (toMin(a.start) ?? 0) - (toMin(b.start) ?? 0));
    }

    // 必要な住所ペアを収集（重複排除）
    const pairs = new Set();
    // 同一住所(表記ゆれ含む)はMaps照会しない(makeLegで移動なし扱い)。別住所のみ取得対象。
    const addPair = (a, b) => { if (a && b && addrKey(a) !== addrKey(b)) pairs.add(a + "||" + b); };
    for (const g of groups.values()) {
      const vs = g.visits;
      for (let i = 1; i < vs.length; i++) addPair(vs[i - 1].address, vs[i].address);
    }

    const pairList = [...pairs];

    // 逐次取得（travelCacheの競合回避＋進捗表示）。キー異常時は中断。
    const travel = new Map();
    let done = 0;
    for (const key of pairList) {
      const [a, b] = key.split("||");
      setSchedStatus(`移動時間を取得中… ${++done}/${pairList.length}`);
      const r = await chrome.runtime.sendMessage({ type: "GET_TRAVEL_TIME", from: a, to: b });
      if (r?.ok) {
        travel.set(key, { sec: r.sec, text: r.text });
      } else {
        travel.set(key, { error: r?.error || "取得失敗" });
        if (r?.needKey) { setSchedStatus(r.error, true); return; }
      }
    }
    const getT = (a, b) => (a && b ? travel.get(a + "||" + b) : null);

    renderSchedule(groups, buffer, getT, unassigned);
    schedResultSig = scheduleSig(res.ym, visits);
    setSchedStatus("");
  } catch (e) {
    setSchedStatus("チェック中にエラーが発生しました: " + e.message, true);
  } finally {
    btn.disabled = false;
  }
}

// gap・travelは分。判定（❌移動だけで間に合わない / ⚠余裕なし / ✓OK）
function legVerdict(gap, travelSec, buffer) {
  const travel = secToMin(travelSec);
  const need = travel + buffer;
  if (gap < travel) return { cls: "ng", mark: "❌", travel, need };
  if (gap < need) return { cls: "warn2", mark: "⚠", travel, need };
  return { cls: "ok", mark: "✓", travel, need };
}

// 1区間(訪問→訪問)を計算。
function makeLeg(from, to, gap, buffer, getT, missingNames) {
  const leg = {
    fromName: from.name, toName: to.name, gap, fromEnd: from.end, toStart: to.start,
    // クリックでカイポケ画面の該当訪問セルへ飛ぶための識別子(uid+日+開始時刻でセルを特定)
    jump: [{ uid: from.uid, day: from.day, start: from.start }, { uid: to.uid, day: to.day, start: to.start }],
  };
  if (!from.address) { missingNames.add(from.name); leg.error = "住所未取得"; return leg; }
  if (!to.address) { missingNames.add(to.name); leg.error = "住所未取得"; return leg; }
  // 同一住所(同居家族の連続訪問など)は移動なし。表記ゆれ(全角半角・ハイフン・空白・丁目番地号)を吸収して判定。
  if (addrKey(from.address) === addrKey(to.address)) {
    leg.travelSec = 0;
    leg.sameAddr = true;
    leg.verdict = { cls: "ok", mark: "✓", travel: 0, need: 0 };
    return leg;
  }
  const t = getT(from.address, to.address);
  if (!t) { leg.error = "移動時間の取得対象外"; return leg; }
  if (t.error) { leg.error = t.error; return leg; }
  leg.travelSec = t.sec;
  leg.verdict = legVerdict(gap, t.sec, buffer);
  return leg;
}

function renderSchedule(groups, buffer, getT, unassigned) {
  const root = $("schedResult");
  root.textContent = "";
  root.classList.remove("hidden");

  const groupArr = [...groups.values()].sort((a, b) => String(a.staff).localeCompare(String(b.staff), "ja"));
  const missingNames = new Set();
  const problems = [];
  const detail = [];

  for (const g of groupArr) {
    const vs = g.visits;
    const legs = [];
    for (let i = 1; i < vs.length; i++) {
      const gap = (toMin(vs[i].start) ?? 0) - (toMin(vs[i - 1].end) ?? 0);
      const leg = makeLeg(vs[i - 1], vs[i], gap, buffer, getT, missingNames);
      legs.push(leg);
      if (leg.verdict && (leg.verdict.cls === "ng" || leg.verdict.cls === "warn2")) problems.push({ g, leg });
    }
    detail.push({ g, legs });
  }

  // 問題のあるルート(職員×日)を集計してカード表示にする（問題ベースのシンプル表示）
  const probByGroup = new Map(); // group -> { ng, warn }
  for (const p of problems) {
    const c = probByGroup.get(p.g) || { ng: 0, warn: 0 };
    if (p.leg.verdict.cls === "ng") c.ng++; else c.warn++;
    probByGroup.set(p.g, c);
  }

  if (probByGroup.size) {
    const totalNg = [...probByGroup.values()].reduce((a, c) => a + c.ng, 0);
    const totalWarn = [...probByGroup.values()].reduce((a, c) => a + c.warn, 0);
    const h = document.createElement("h3");
    h.className = "probHead";
    const parts = [];
    if (totalNg) parts.push(`移動時間が足りない区間${totalNg}件`);
    if (totalWarn) parts.push(`余裕のない区間${totalWarn}件`);
    h.textContent = `要確認 ${probByGroup.size}ルート（${parts.join("・")}）`;
    root.appendChild(h);
    const hint = document.createElement("div");
    hint.className = "legSub";
    hint.textContent = "区間をクリックすると、カイポケ画面の該当訪問へスクロールします。";
    root.appendChild(hint);

    // ❌を含むルートが先、次に⚠のみ。同格は職員名順。クリックでその日の全行程を展開。
    const probGroups = [...probByGroup.entries()].sort((a, b) => {
      const ra = a[1].ng ? 0 : 1, rb = b[1].ng ? 0 : 1;
      if (ra !== rb) return ra - rb;
      return String(a[0].staff).localeCompare(String(b[0].staff), "ja");
    });
    for (const [g, c] of probGroups) {
      const card = document.createElement("details");
      card.className = "probCard" + (c.ng ? "" : " warn2");
      const sum = document.createElement("summary");
      const cnt = [];
      if (c.ng) cnt.push(`移動時間が足りない区間${c.ng}件`);
      if (c.warn) cnt.push(`余裕のない区間${c.warn}件`);
      sum.textContent = `${c.ng ? "❌" : "⚠"} ${g.staff}（${ymdLabel(g.ym, g.day)}）— ${cnt.join("・")}`;
      card.appendChild(sum);
      const body = document.createElement("div");
      body.className = "probBody";
      const d = detail.find((x) => x.g === g);
      for (const leg of d.legs) body.appendChild(legLine(leg, ""));
      card.appendChild(body);
      // カードを開いたら最初の問題区間までパネルを自動スクロール
      card.addEventListener("toggle", () => {
        if (!card.open) return;
        const target = card.querySelector(".leg.ng, .leg.warn2") || card;
        target.scrollIntoView({ behavior: "smooth", block: "center" });
      });
      root.appendChild(card);
    }
  } else {
    const judged = detail.reduce((a, d) => a + d.legs.filter((l) => l.verdict).length, 0);
    const ok = document.createElement("div");
    ok.className = "leg ok";
    ok.textContent = judged
      ? `✓ 問題なし：判定した${judged}区間はすべて間に合う見込みです。`
      : "✓ 判定対象の連続訪問はありませんでした。";
    root.appendChild(ok);
  }

  // 住所未取得（折りたたみ1行。展開で名前と対処）
  if (missingNames.size) {
    const card = document.createElement("details");
    card.className = "subCard";
    const sum = document.createElement("summary");
    sum.textContent = `⚠ 住所未取得 ${missingNames.size}名（この利用者の区間は判定できません）`;
    card.appendChild(sum);
    const p = document.createElement("div");
    p.className = "legSub";
    p.textContent = [...missingNames].join("、") + "（基本情報の取り込み、または設定の利用者データ読み込みで住所を登録してください）";
    card.appendChild(p);
    root.appendChild(card);
  }

  // 補足（職員未割当）
  if (unassigned) {
    const n = document.createElement("div");
    n.className = "legSub";
    n.textContent = `※ 職員未割当の予定が ${unassigned}件 あります（判定対象外）。`;
    root.appendChild(n);
  }

  // 参考：全職員の行程（折りたたみ。✓含む従来の全一覧を検算用に残す）
  if (detail.length) {
    const card = document.createElement("details");
    card.className = "subCard";
    const sum = document.createElement("summary");
    sum.textContent = "参考：全職員の行程を表示";
    card.appendChild(sum);
    for (const d of detail) {
      const g = d.g;
      const sec = document.createElement("div");
      sec.className = "schedGroup";
      const h = document.createElement("h3");
      h.textContent = `${g.staff}（${ymdLabel(g.ym, g.day)}・訪問${g.visits.length}件）`;
      sec.appendChild(h);
      for (const leg of d.legs) sec.appendChild(legLine(leg, ""));
      card.appendChild(sec);
    }
    root.appendChild(card);
  }
}

// 区間クリックでカイポケ画面の該当訪問(2件)へスクロール＆ハイライトさせる
async function locateVisits(targets) {
  const res = await sendToPage({ type: "SCROLL_TO_VISITS", targets });
  if (!res?.ok) {
    setSchedStatus(res?.error || "カイポケ画面で該当の訪問を見つけられませんでした。ページを再読込してください。", true);
  } else {
    setSchedStatus("");
  }
}

function legLine(leg, prefix) {
  const div = document.createElement("div");

  if (leg.jump) {
    div.classList.add("clickable");
    div.title = "クリックでカイポケ画面の該当訪問へ移動";
    div.addEventListener("click", () => locateVisits(leg.jump));
  }

  if (leg.error) {
    div.className = "leg info";
    div.textContent = `${prefix}${leg.fromName} → ${leg.toName}：${leg.error}`;
    return div;
  }

  const v = leg.verdict;
  div.className = "leg " + v.cls;
  const head = document.createElement("div");
  const mark = document.createElement("span");
  mark.className = "v";
  mark.textContent = `${v.mark} `;
  head.appendChild(mark);
  head.appendChild(document.createTextNode(
    `${prefix}${leg.fromName}（〜${leg.fromEnd}）→ ${leg.toName}（${leg.toStart}〜）`
  ));
  div.appendChild(head);
  const sub = document.createElement("div");
  sub.className = "legSub";
  sub.textContent = leg.sameAddr
    ? `空き${leg.gap}分 / 同一住所（移動なし）`
    : `空き${leg.gap}分 / 移動${v.travel}分（必要${v.need}分）`;
  div.appendChild(sub);
  return div;
}
