// カイポケ 記録書Ⅱ(新規作成/既存編集)ページの読み取り・書き込み
// 対象URL: https://r.kaipoke.biz/bizhnc/careRecordAdd/index/  (新規作成)
//          https://r.kaipoke.biz/bizhnc/careRecordEdit/index/ (既存編集) ※画面ID HNC091714 共通
//
// セレクタはすべて SEL / VITAL_FIELDS に集約する。
// カイポケ側の画面更新で動かなくなった場合はここだけ直せばよい。

const SEL = {
  // 利用者名 — サイドパネルでの表示専用。APIには送らない
  userSurname: 'input[name="userSurname"]',
  userName: 'input[name="userName"]',
  // 訪問概要
  serviceDate: 'input[name="serviceDate"]', // 例 "2026/05/01"
  emergency: "#emergency",
  serviceCode: "#serviceCode",
  visitStartHour: "#visitYearStartHour",
  visitStartMin: "#visitMonthStartMin",
  visitEndHour: "#visitYearEndHour",
  visitEndMin: "#visitMonthEndHour", // ※分のセレクトだがカイポケ側のidが "EndHour"
  // 観察事項
  consciousness: "#consciousness",
  // 利用者の内部ID(基本情報・ADLページと共通のキー)
  userInternalId: "#userInternalId",
  // 出力先(観察記録の自由記述欄)
  observationComment: "#observationComment",
  // フォームid: 新規=careRecordAddForm / 既存編集=careRecordUpdateForm
  form: "#careRecordAddForm, #careRecordUpdateForm",
};

// バイタル入力欄(接尾辞 1〜3 = 1回目〜3回目)
const VITAL_FIELDS = [
  ["temperature", "体温(℃)"],
  ["pressureHigh", "血圧 収縮期"],
  ["pressureLow", "血圧 拡張期"],
  ["pulse", "脈拍(回/分)"],
  ["spo2", "SpO2(%)"],
  ["breathing", "呼吸(回/分)"],
  ["bloodSugarLevel", "血糖値"],
  ["weight", "体重(kg)"],
];

function val(selector) {
  const el = document.querySelector(selector);
  return el ? el.value.trim() : "";
}

// セレクトの選択中テキスト。"-" "--" 等のプレースホルダは空扱い
function selectedText(selector) {
  const el = document.querySelector(selector);
  if (!el || !el.selectedOptions || !el.selectedOptions.length) return "";
  const opt = el.selectedOptions[0];
  if (!opt.value) return "";
  const text = opt.textContent.trim();
  return /^-+$/.test(text) ? "" : text;
}

function visitTime() {
  const sh = val(SEL.visitStartHour);
  const sm = val(SEL.visitStartMin);
  const eh = val(SEL.visitEndHour);
  const em = val(SEL.visitEndMin);
  const start = sh && sm ? `${sh}:${sm}` : "";
  const end = eh && em ? `${eh}:${em}` : "";
  if (start && end) return `${start}〜${end}`;
  return start || "";
}

// 訪問日: 画面でカレンダー変更した値は datepicker 連動の #currentDateStartUser に入る。
// serviceDate はページ表示時の値で、変更が反映されないため、currentDateStartUser を優先する。
function visitDate() {
  return (
    val("#currentDateStartUser") ||
    val(SEL.serviceDate) ||
    val('input[name="dateSelect"]')
  );
}

function vitals() {
  const rounds = [];
  for (let i = 1; i <= 3; i++) {
    const values = {};
    for (const [field, label] of VITAL_FIELDS) {
      const v = val(`#${field}${i}`);
      if (v) values[label] = v;
    }
    const remarks = val(`#vitalRemarks${i}`);
    if (remarks) values["特記"] = remarks;
    if (Object.keys(values).length) rounds.push({ round: i, values });
  }
  return rounds;
}

// フォーム内でチェックされた項目を「行ラベル: 選択肢ラベル」形式で収集する。
// 写真の印刷対象チェック(初期状態でON)と緊急訪問(別途取得)は除外。
function checkedItems() {
  const form = document.querySelector(SEL.form);
  if (!form) return [];
  const items = [];
  const seen = new Set();
  const inputs = form.querySelectorAll(
    'input[type="checkbox"]:checked, input[type="radio"]:checked'
  );
  for (const input of inputs) {
    if (input.id === "emergency") continue;
    if ((input.name || "").startsWith("photoPrintTarget")) continue;

    let optionLabel = "";
    if (input.id) {
      const label = form.querySelector(`label[for="${CSS.escape(input.id)}"]`);
      if (label) optionLabel = label.textContent.trim();
    }
    if (!optionLabel) {
      const wrapping = input.closest("label");
      if (wrapping) optionLabel = wrapping.textContent.trim();
    }
    if (!optionLabel) continue;

    // 行の見出し(表の左列)があれば文脈として付ける
    let context = "";
    const row = input.closest("tr");
    if (row) {
      const head = row.querySelector("td.leftColumn") || row.querySelector("td");
      if (head && !head.contains(input)) {
        context = head.textContent.replace(/[\s*＊]+/g, " ").trim();
      }
    }
    const item = context && context !== optionLabel ? `${context}: ${optionLabel}` : optionLabel;
    if (!seen.has(item)) {
      seen.add(item);
      items.push(item);
    }
  }
  return items;
}

function extract() {
  const surname = val(SEL.userSurname);
  const name = val(SEL.userName);
  const emergencyEl = document.querySelector(SEL.emergency);
  return {
    // 表示専用(panel.js が API 送信ペイロードから除外する)
    patientNameLocal: [surname, name].filter(Boolean).join(" "),
    // 基本情報/ADLページと紐づくキー(APIには送らない)
    userInternalId: val(SEL.userInternalId),
    visitDate: visitDate(),
    visitTime: visitTime(),
    serviceContent: selectedText(SEL.serviceCode),
    emergency: !!(emergencyEl && emergencyEl.checked),
    consciousness: selectedText(SEL.consciousness),
    vitals: vitals(),
    // 1回目の実測バイタル(看護師が入力した値。SOAP生成の文脈に使う)
    vitals1: {
      temp: val("#temperature1"),
      bpHigh: val("#pressureHigh1"),
      bpLow: val("#pressureLow1"),
      pulse: val("#pulse1"),
    },
    checkedItems: checkedItems(),
    existingComment: val(SEL.observationComment),
  };
}

function insert(text, mode) {
  const el = document.querySelector(SEL.observationComment);
  if (!el) return { ok: false, error: "観察記録欄が見つかりません" };
  const current = el.value.trim();
  el.value = mode === "append" && current ? `${current}\n${text}` : text;
  // カイポケ側の未保存チェック(dirty_check.js)等に変更を認識させる
  el.dispatchEvent(new Event("input", { bubbles: true }));
  el.dispatchEvent(new Event("change", { bubbles: true }));
  return { ok: true };
}

// 学習用: 生成した仮バイタルを1回目の欄に「表示」するだけ。
// 本番記録への混入を避けるため input/change は発火させない
// (カイポケ側の onchange 登録・保存・未保存チェックに乗せない＝保存はせず画面に書くのみ)。
function insertVitals(v) {
  v = v || {};
  const map = [
    ["#temperature1", v.temp],
    ["#pressureHigh1", v.bpHigh],
    ["#pressureLow1", v.bpLow],
    ["#pulse1", v.pulse],
  ];
  let filled = 0;
  for (const [sel, value] of map) {
    if (value == null || value === "") continue;
    const el = document.querySelector(sel);
    if (!el) continue;
    el.value = value; // 表示のみ。イベントは発火しない(保存・登録に乗せない)
    filled++;
  }
  return { ok: filled > 0, filled };
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type === "PING") {
    sendResponse({ ok: true, isRecordPage: !!document.querySelector(SEL.observationComment) });
  } else if (msg?.type === "EXTRACT") {
    sendResponse({ ok: true, data: extract() });
  } else if (msg?.type === "INSERT") {
    sendResponse(insert(msg.text, msg.mode));
  } else if (msg?.type === "INSERT_VITALS") {
    sendResponse(insertVitals(msg.vitals));
  }
});
