const $ = (id) => document.getElementById(id);

// 既存設定を読み込む。キーは値を表示せず「設定済み」を示すだけにする。
let hasKey = false;
chrome.storage.local.get(["openaiKey", "model"]).then((o) => {
  hasKey = !!o.openaiKey;
  $("key").placeholder = hasKey ? "設定済み（変更する場合のみ入力）" : "sk-...";
  $("model").value = o.model || "";
});

$("save").addEventListener("click", async () => {
  const keyInput = $("key").value.trim();
  const model = $("model").value.trim();
  const toSet = {};

  if (keyInput) {
    toSet.openaiKey = keyInput;
  } else if (!hasKey) {
    setStatus("APIキーを入力してください。", true);
    return;
  }
  // model は空なら既定(gpt-4o-mini)を使うため、空文字でも保存（background側で既定にフォールバック）
  toSet.model = model;

  await chrome.storage.local.set(toSet);
  hasKey = hasKey || !!keyInput;
  $("key").value = "";
  $("key").placeholder = "設定済み（変更する場合のみ入力）";
  setStatus("保存しました。");
});

function setStatus(msg, isError = false) {
  const el = $("status");
  el.textContent = msg;
  el.classList.toggle("error", isError);
  if (!isError) setTimeout(() => (el.textContent = ""), 3000);
}

// ===== 移動チェック設定（Google Mapsキー・余裕分）=====
let hasMapsKey = false;
chrome.storage.local.get(["mapsApiKey", "bufferMin"]).then((o) => {
  hasMapsKey = !!o.mapsApiKey;
  $("mapsKey").placeholder = hasMapsKey ? "設定済み（変更する場合のみ入力）" : "AIza...";
  $("buffer").value = o.bufferMin != null ? String(o.bufferMin) : "";
});

function setTravelStatus(msg, isError = false) {
  const el = $("travelStatus");
  el.textContent = msg;
  el.classList.toggle("error", isError);
  if (!isError) setTimeout(() => { if (el.textContent === msg) el.textContent = ""; }, 4000);
}

$("saveTravel").addEventListener("click", async () => {
  const keyInput = $("mapsKey").value.trim();
  const bufRaw = $("buffer").value.trim();
  const toSet = {};
  if (keyInput) toSet.mapsApiKey = keyInput;
  if (bufRaw === "") {
    toSet.bufferMin = 10;
  } else {
    const n = parseInt(bufRaw, 10);
    if (isNaN(n) || n < 0) { setTravelStatus("余裕（分）は0以上の数字で入力してください。", true); return; }
    toSet.bufferMin = n;
  }
  await chrome.storage.local.set(toSet);
  hasMapsKey = hasMapsKey || !!keyInput;
  $("mapsKey").value = "";
  $("mapsKey").placeholder = hasMapsKey ? "設定済み（変更する場合のみ入力）" : "AIza...";
  $("buffer").value = String(toSet.bufferMin);
  setTravelStatus("保存しました。");
});

$("clearCache").addEventListener("click", async () => {
  await chrome.storage.local.remove("travelCache");
  setTravelStatus("移動時間キャッシュを削除しました。次回チェック時に再取得します。");
});

// ===== 利用者データの引き渡し（書き出し／読み込み）=====
// 紐付けキー userInternalId 単位で属性のみを移送する。
// soapHistory・APIキーは含めない。取り込み先では既存の soapHistory は保持し属性のみ上書きマージ。
const PATIENT_FIELDS = ["name", "gender", "birth", "diagnosis", "care", "address"];
const EXPORT_TYPE = "kaipoke-record-assist-patients";

function hStatus(msg, isError = false) {
  const el = $("handoverStatus");
  el.textContent = msg;
  el.classList.toggle("error", isError);
  if (!isError) setTimeout(() => { if (el.textContent === msg) el.textContent = ""; }, 5000);
}

$("exportBtn").addEventListener("click", async () => {
  const { patients } = await chrome.storage.local.get("patients");
  const src = patients || {};
  const out = {};
  Object.keys(src).forEach((uid) => {
    const rec = src[uid] || {};
    const clean = {};
    PATIENT_FIELDS.forEach((k) => { if (rec[k] != null && rec[k] !== "") clean[k] = rec[k]; });
    if (Object.keys(clean).length) out[uid] = clean;
  });
  const count = Object.keys(out).length;
  if (!count) { hStatus("書き出すデータがありません。先に各ページで取り込んでください。", true); return; }

  const payload = { type: EXPORT_TYPE, version: 1, exportedAt: new Date().toISOString(), count, patients: out };
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const d = new Date();
  const stamp = `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, "0")}${String(d.getDate()).padStart(2, "0")}`;
  const a = document.createElement("a");
  a.href = url;
  a.download = `kaipoke-patients-${stamp}.json`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
  hStatus(`${count}人分を書き出しました。`);
});

$("importBtn").addEventListener("click", () => $("importFile").click());

$("importFile").addEventListener("change", async (e) => {
  const file = e.target.files && e.target.files[0];
  e.target.value = ""; // 同じファイルを連続選択できるように
  if (!file) return;
  let data;
  try {
    data = JSON.parse(await file.text());
  } catch {
    hStatus("読み込み失敗: JSONとして解析できません。", true);
    return;
  }
  if (!data || data.type !== EXPORT_TYPE || !data.patients || typeof data.patients !== "object") {
    hStatus("このツールの書き出しファイルではないようです。", true);
    return;
  }
  const incoming = data.patients;
  const { patients } = await chrome.storage.local.get("patients");
  const merged = patients || {};
  let added = 0, updated = 0;
  Object.keys(incoming).forEach((uid) => {
    const inc = incoming[uid] || {};
    const clean = {};
    PATIENT_FIELDS.forEach((k) => { if (inc[k] != null && inc[k] !== "") clean[k] = String(inc[k]); });
    if (!Object.keys(clean).length) return;
    if (merged[uid]) updated++; else added++;
    // 既存の soapHistory 等は保持し、属性のみ上書きマージ
    merged[uid] = Object.assign({}, merged[uid] || {}, clean, { importedAt: Date.now() });
  });
  if (added || updated) await chrome.storage.local.set({ patients: merged });

  if (!added && !updated) { hStatus("読み込めるデータがありませんでした。", true); return; }
  hStatus(`読み込み完了: 新規 ${added}人 / 更新 ${updated}人。`);
});
