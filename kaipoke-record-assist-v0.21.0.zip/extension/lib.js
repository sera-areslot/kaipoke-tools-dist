// 各ページの content script で共通利用するヘルパー。
// 利用者属性のキャッシュ（chrome.storage.local）と、取り込みボタン/トースト等のUI。
//
// キャッシュ構造:
//   chrome.storage.local.patients = {
//     "<userInternalId>": { name, gender, birth, diagnosis, care, basicAt, adlAt }
//   }
// userInternalId は 基本情報/ADL/記録書Ⅱ の3ページ共通で、紐づけの主キー。

const KRA = {
  // userInternalId をページから取得（基本情報ページは "MEM090304:userInternalId" 等の接尾辞付き）
  userInternalId() {
    const el = document.querySelector('input[name$="userInternalId"], #userInternalId');
    return el ? String(el.value || "").trim() : "";
  },

  // ページ見出しから氏名を推定（"山田 太郎 様 ADL..." → "山田 太郎"）。表示用。
  pageUserName() {
    const h = document.querySelector("h1.page-title");
    if (!h) return "";
    const t = h.textContent.replace(/ /g, " ").replace(/\s+/g, " ").trim();
    const m = t.match(/^(.*?)\s*様/);
    return m ? m[1].trim() : "";
  },

  // th のラベル文字に一致する行の td テキストを返す（基本情報ページ用）
  thToTd(label) {
    const ths = document.querySelectorAll("th");
    for (const th of ths) {
      if (th.textContent.replace(/\s+/g, "").trim() === label) {
        let td = th.nextElementSibling;
        while (td && td.tagName !== "TD") td = td.nextElementSibling;
        if (td) return td.textContent.replace(/ /g, " ").replace(/\s+/g, " ").trim();
      }
    }
    return "";
  },

  valOf(selector) {
    const el = document.querySelector(selector);
    return el ? String(el.value || "").trim() : "";
  },

  async loadPatients() {
    const o = await chrome.storage.local.get("patients");
    return o.patients || {};
  },

  async getPatient(uid) {
    const p = await this.loadPatients();
    return p[uid] || null;
  },

  // 既存に対してフィールドをマージ保存（基本情報とADLは別ボタンで部分更新するため）
  // 既存に対してフィールドをマージ保存（基本情報とADLは別ボタンで部分更新するため）。
  // 再取り込み時は、渡された項目を最新値で上書きし、渡していない項目(soapHistory等)は保持する。
  // undefined のフィールドは無視する（空値で既存を消さないため）。
  async savePatientFields(uid, fields) {
    const clean = {};
    Object.keys(fields || {}).forEach((k) => {
      if (fields[k] !== undefined) clean[k] = fields[k];
    });
    const p = await this.loadPatients();
    p[uid] = Object.assign({}, p[uid] || {}, clean);
    await chrome.storage.local.set({ patients: p });
    return p[uid];
  },

  // 画面右下に固定ボタンを出す。カイポケの保存ボタン等と重ならないよう既定位置を上げ、
  // さらにドラッグで移動できるようにする(他ページで重なっても避けられる)。
  injectButton(label, onClick) {
    if (document.getElementById("kra-import-btn")) return;
    const btn = document.createElement("button");
    btn.id = "kra-import-btn";
    btn.textContent = label;
    btn.title = "ドラッグで移動できます";
    Object.assign(btn.style, {
      position: "fixed", right: "16px", bottom: "96px", zIndex: 2147483647,
      background: "#2e7d6e", color: "#fff", border: "none", borderRadius: "6px",
      padding: "10px 14px", fontSize: "13px", cursor: "move",
      boxShadow: "0 2px 8px rgba(0,0,0,.25)", fontFamily: "sans-serif",
    });

    // ドラッグ移動(クリックと区別する)。保存ボタン等と重なったらユーザーが避けられる。
    let dragging = false, moved = false, sx = 0, sy = 0, ox = 0, oy = 0;
    btn.addEventListener("mousedown", (e) => {
      dragging = true; moved = false;
      sx = e.clientX; sy = e.clientY;
      const r = btn.getBoundingClientRect();
      ox = r.left; oy = r.top;
      e.preventDefault();
    });
    window.addEventListener("mousemove", (e) => {
      if (!dragging) return;
      const dx = e.clientX - sx, dy = e.clientY - sy;
      if (Math.abs(dx) > 4 || Math.abs(dy) > 4) moved = true;
      Object.assign(btn.style, { left: ox + dx + "px", top: oy + dy + "px", right: "auto", bottom: "auto" });
    });
    window.addEventListener("mouseup", () => { dragging = false; });

    btn.addEventListener("click", async () => {
      if (moved) { moved = false; return; } // ドラッグ操作のクリックは無視
      btn.disabled = true;
      const orig = btn.textContent;
      btn.textContent = "取り込み中…";
      try { await onClick(); } catch (e) { KRA.toast("エラー: " + e.message, true); }
      btn.textContent = orig;
      btn.disabled = false;
    });
    document.body.appendChild(btn);
  },

  toast(msg, isError) {
    const d = document.createElement("div");
    d.textContent = msg;
    Object.assign(d.style, {
      position: "fixed", right: "16px", bottom: "152px", zIndex: 2147483647,
      background: isError ? "#c0392b" : "#333", color: "#fff",
      padding: "8px 14px", borderRadius: "4px", fontSize: "13px",
      maxWidth: "360px", fontFamily: "sans-serif", boxShadow: "0 2px 8px rgba(0,0,0,.25)",
    });
    document.body.appendChild(d);
    setTimeout(() => d.remove(), 4000);
  },
};
