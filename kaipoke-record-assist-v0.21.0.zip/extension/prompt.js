// 観察記録(SOAP)生成プロンプト。
// 利用者の「療養状況」(看護師が記録した実際の状況)に基づいて整え、無い事実は作らない。
// 記録書Ⅱの観察記録欄(1つのテキスト欄)に入れるため、SOAPの4行テキストで出力する。
//
// ★文体・ルールの調整はこのファイルだけで完結する(拡張機能を再読み込みすれば反映)。

export const SYSTEM_PROMPT = [
  "あなたは訪問看護記録のSOAP欄を作成する補助ツールです。",
  "利用者の「療養状況」（看護師が記録した実際の状況）に基づき、S/O/A/P を簡潔に整えます。",
  "療養状況に書かれていない新しい事実（症状・所見・評価・数値）は作り出さないでください。",
  "ただし「本日の様子」として与えられた日常の出来事（睡眠・食事・外出・来訪など）は記載してかまいません。",
  "",
  "# 形式（重要）",
  "- 出力は次の4行のみ。前後に説明・コードフェンス・見出しを付けない。",
  "  S：…",
  "  O：…",
  "  A：…",
  "  P：…",
  "- 各行は体言止め・短い言い切りでまとめる。句読点（。、）は使わない。",
  "- 文章にせず要点を短く。1項目おおむね15〜25文字程度。",
  "- 例: 「S：夜中に何度か目覚めた」「O：表情やや硬く飲酒継続中」",
  "      「A：睡眠障害継続し活動性低下」「P：睡眠状況確認し傾聴実施」",
  "",
  "# 内容",
  "- S=利用者・家族の訴え / O=観察された状態 / A=評価 / P=対応・計画。",
  "- Sはその日の体調・生活に関する本人の言葉にする。療養状況にある同じ出来事・境遇",
  "  （例: 経済状況・家族の事情）を毎回Sにしない。直近の記録とは言い回しだけでなく話題も変える。",
  "- 療養状況に該当が無い項目は「【　】」とする。",
  "- バイタル数値はSOAPに入れない（画面の数値欄にあるため）。",
  "- 「本日の様子」が与えられた場合、その出来事をS/Oに自然に反映し、A/Pも整合させる",
  "  （内容の着眼点を変えるための設定。療養状況と矛盾する記載にはしない）。",
  "- 「本日の着眼点」が与えられた場合、S/Oはその話題を中心に組み立てる。傷病名にある症状の",
  "  その日の程度（良い/普段どおり/やや強い）を書くのはよい（新しい診断・急変・重大な所見は作らない）。",
  "- 「本日の様子」が平穏・良好系のときは、調子が良く落ち着いていることが伝わる記載にする",
  "  （慢性の訴えを毎回羅列しない）。",
  "- 症状の程度は毎回同じにしない。「本日の調子」に厳密に合わせる：軽い日は",
  "  「昨日より痛みが和らいだ」「今日は楽」のような比較・前向き表現、強い日はその旨を書く。",
  "- A（評価）も「本日の調子」に連動させ、毎回「深刻・著しい支障」としない。",
  "  軽い日は「症状軽減傾向」「状態安定」、普段どおりの日は「経過観察継続」等を使い分ける。",
  "- P（計画）はその日の具体的な対応（傾聴・状態確認・助言・声かけ・次回の確認事項など）。",
  "  毎回「計画の見直し」「アプローチ再考」のような大きな話にしない。",
  "- 客観的・簡潔で、訪問看護記録として自然な表現にする（誇張しない）。",
  "",
  "# 揺らぎ（毎月10件以上記載するため）",
  "- 「直近の記録」が与えられたら、それらと語彙・語順・文末表現・着眼点を必ず変え、文言を繰り返さない。",
  "- 同じ事実でも、表現・言い回し・どの側面を先に書くかを変える。",
  "- ただし療養状況に無い事実は作らない（揺らすのは言い回しと「本日の様子」の範囲だけ）。",
].join("\n");

export function buildUserPrompt(record, supplement, priorSoaps, scenario, focus) {
  const r = record || {};
  const v = r.vitals || {};
  const bg = [];
  if (r.gender) bg.push("性別: " + r.gender);
  if (r.birth) bg.push("生年月日: " + r.birth);
  if (r.diagnosis) bg.push("傷病名: " + r.diagnosis);

  const vit = [];
  if (v.temp) vit.push("体温 " + v.temp);
  if (v.bpHigh || v.bpLow) vit.push("血圧 高" + (v.bpHigh || "—") + "/低" + (v.bpLow || "—"));
  if (v.pulse) vit.push("脈拍 " + v.pulse);

  const lines = [
    "## 背景（文脈のみ。ここから所見を作らない）",
    bg.join(" / ") || "（情報なし）",
    "",
    "## 療養状況（看護師が記録した実際の状況。SOAPはこれに基づく）",
    r.care || "（記載なし）",
    "",
    "## この訪問",
    "日付: " + (r.visitDate || "（不明）"),
  ];
  if (vit.length) lines.push("実測バイタル（参考）: " + vit.join(" / "));
  if (scenario) {
    lines.push(
      "",
      "## 本日の様子（この日の設定。S/Oに自然に反映し、療養状況と矛盾させない。実測バイタルがある場合はその値と矛盾する身体状態も書かない）",
      scenario.label + "：" + scenario.soap,
      "本日の調子：" + (scenario.cond || "普段どおり")
    );
  }
  if (focus) {
    lines.push("", "## 本日の着眼点（S/Oの中心テーマ。傷病名・療養状況の範囲で）", focus);
  }
  if (supplement) lines.push("", "## 補足", supplement);

  if (priorSoaps && priorSoaps.length) {
    lines.push("", "## 直近の記録（これらと言い回し・着眼点を変える。同じにしない）");
    priorSoaps.forEach((s, i) => lines.push("--- " + (i + 1) + " ---", s));
  }

  lines.push(
    "",
    "療養状況に基づき、指定の4行（S：/O：/A：/P：、体言止め・句読点なし）だけを出力してください。",
    "療養状況に無いことは作らず、該当が無い項目は【　】に。前回までと語彙・語順・文末表現・着眼点を変え、文言を繰り返さないでください。"
  );
  return lines.join("\n");
}


// ============================================================
// 学習用: 演習問題づくり用のバイタル仮値生成。
// ★これは学習用の演習データ。実在の測定値ではなく、実際の提出・請求には使わない。
// ============================================================

export const SYSTEM_VITALS = [
  "あなたは看護学生向けの演習問題を作成する補助ツールです。",
  "架空の利用者の背景と療養状況から、その訪問日に観察されうる「現実的なバイタル",
  "（体温・血圧・脈拍）の仮の値」を1つ提案します。",
  "これは学習用の演習データであり、実在する人物の測定値ではありません。",
  "",
  "# ルール",
  "- 生理学的に妥当な範囲で、年齢・傷病名・療養状況に整合させる。",
  "  例: 高血圧があれば血圧は高め、安定した精神科の利用者なら概ね正常範囲、など。",
  "- 体温は℃の数値(例 36.7)、血圧は収縮期(高)と拡張期(低)に分ける、脈拍は回/分。",
  "- 脈拍の目安: 65歳以上は60〜80中心、65歳未満は65〜90中心（傷病名・状況により妥当な範囲で外れてよい）。",
  "- 血圧の下(拡張期)と脈拍を同じ値にしない。",
  "- 日ごとに自然なばらつきを持たせ、毎回まったく同じ値にはしない（特に体温は0.1〜0.3程度動かす）。",
  "- 「本日の様子」が与えられたら、その生理的影響を値に反映する。ただし「値の傾向」の指定がある項目は傾向を優先する。",
  "- 数値のみ。単位・記号・説明を付けない。",
  "",
  "# 出力",
  "- 次のJSONだけを出力する。前後に説明文・コードフェンスを付けない。",
  '  {"temp":"36.7","bpHigh":"122","bpLow":"78","pulse":"72"}',
].join("\n");

export function buildVitalsUserPrompt(record, bias, scenario) {
  const r = record || {};
  const lines = ["## 架空の利用者（演習用）"];
  if (r.gender) lines.push("性別: " + r.gender);
  if (r.birth) lines.push("生年月日: " + r.birth + "（年齢を推定）");
  if (r.diagnosis) lines.push("傷病名: " + r.diagnosis);
  if (r.care) lines.push("療養状況: " + r.care);
  lines.push("", "## 訪問日: " + (r.visitDate || "（不明）"));

  if (scenario) {
    lines.push("", "## 本日の様子（この日の設定。生理的影響を値に反映する）", scenario.label + "：" + scenario.vitals);
  }

  // 任意の傾向指定（低め/高め）。医学的整合を優先しつつ、その方向に寄せる。
  const b = bias || {};
  const dir = (v) => (v === "high" ? "高め" : v === "low" ? "低め" : "");
  const tend = [];
  if (dir(b.temp)) tend.push("体温は" + dir(b.temp));
  if (dir(b.bp)) tend.push("血圧は" + dir(b.bp));
  if (dir(b.pulse)) tend.push("脈拍は" + dir(b.pulse));
  if (tend.length) {
    lines.push(
      "",
      "## 値の傾向（できるだけこの方向に寄せる。ただし年齢・傷病名・療養状況と矛盾しない、生理学的に妥当な範囲で）",
      "- " + tend.join(" / ")
    );
  }

  lines.push("", "この日の現実的なバイタルの仮値を、指定のJSONで1つだけ出力してください。");
  return lines.join("\n");
}


// ============================================================
// 本日のシナリオ（内容のランダム性）
// 言い回しの揺らぎ(直近履歴)とは別に「その日の出来事」を変えるための設定。
// コード側で無作為抽選し、同じシナリオをバイタル生成とSOAP生成の両方に渡して整合させる。
// 仮バイタル生成時(＝バイタル欄が空の学習用モード)だけ使う。実測バイタル入力時は使わない。
//
//   includeIf: 療養状況＋傷病名にこの語が含まれるときだけ候補にする
//   excludeIf: この語が含まれていたら候補にしない（状態に合わない話題を出さないための安全弁）
//   months:    この月のときだけ候補（訪問日から判定。月不明なら候補外）
//   weight:    抽選の重み（平穏な日を多めにして現実的な頻度にする）
//
// ★シナリオの追加・調整もこのファイルだけで完結する。
export const SCENARIOS = [
  { key: "calm", label: "特変なし（平穏な一日）", weight: 3,
    cond: "落ち着いている（苦痛の訴えは軽い）",
    soap: "体調は落ち着いていて調子の良い一日 苦痛の訴えは軽めか無しで 穏やかに過ごす様子を記載",
    vitals: "普段どおりの安定した値" },
  { key: "good", label: "症状が軽く調子が良い", weight: 3,
    cond: "普段より症状が軽い（「昨日より痛みが和らいだ」等の比較表現を使ってよい）",
    soap: "痛みや不安など普段の症状が軽い想定 前向きな発言や活気をS/Oに反映",
    vitals: "安定した良好な値" },
  { key: "sleep_poor", label: "夜間に中途覚醒あり", weight: 1,
    cond: "やや不調（睡眠不足の影響）",
    soap: "夜間の眠りが浅く中途覚醒があった想定 眠気や倦怠感をS/Oに反映",
    vitals: "睡眠不足の影響で血圧をやや高め(+5〜10)、脈拍をやや高め(+3〜8)に" },
  { key: "sleep_good", label: "よく眠れた", weight: 2,
    cond: "普段より症状が軽め（休養がとれている）",
    soap: "睡眠が十分とれた想定 表情や活気の良さをS/Oに反映",
    vitals: "安定した落ち着いた値" },
  { key: "home", label: "終日在宅で静かに過ごした", weight: 1,
    cond: "普段どおり",
    soap: "外出なくテレビや読書などで静かに過ごした想定",
    vitals: "安静時の落ち着いた値 脈拍は低め寄り" },
  { key: "bowel", label: "便通の話題（便秘気味など）", weight: 1,
    cond: "普段どおり",
    soap: "便秘気味や排便状況の訴えなど便通に関する話題をSに反映 水分摂取や腹部状態の確認をPに",
    vitals: "バイタルへの影響は小さい" },
  { key: "visitor", label: "家族・知人の来訪あり", weight: 1,
    cond: "普段どおり（気分は明るい）",
    soap: "家族や知人の来訪で気分が良い想定 表情の明るさをOに反映",
    vitals: "気分が安定し落ち着いた値" },
  { key: "outing", label: "外出あり（散歩・買い物など）", weight: 1,
    excludeIf: ["寝たきり", "終日臥床", "歩行不可", "歩行困難"],
    cond: "落ち着いている（外出できる程度に症状は軽い）",
    soap: "散歩や買い物などの外出があった想定 軽い疲労感や充実感を反映",
    vitals: "活動後のため脈拍をやや高め(+5〜10)に" },
  { key: "exercise", label: "体操・リハビリを実施", weight: 1,
    excludeIf: ["寝たきり", "終日臥床"],
    cond: "落ち着いている（体を動かせる程度に症状は軽い）",
    soap: "体操や自主リハビリに取り組んだ想定 取り組みの様子をO/Pに反映",
    vitals: "運動後のため脈拍をやや高め(+5〜10)に" },
  { key: "appetite_good", label: "食欲良好", weight: 1,
    excludeIf: ["経管", "胃ろう", "胃瘻", "経鼻"],
    cond: "普段どおり〜軽め",
    soap: "食事をおいしく摂れている想定 摂取状況をS/Oに反映",
    vitals: "安定した値" },
  { key: "appetite_low", label: "食欲やや低下", weight: 1,
    excludeIf: ["経管", "胃ろう", "胃瘻", "経鼻"],
    cond: "やや不調",
    soap: "食欲が普段よりやや落ちている想定 摂取量の減少をS/Oに 水分摂取の声かけをPに",
    vitals: "大きな変動はないが やや元気のない印象に整合させる" },
  { key: "alcohol", label: "前日に飲酒あり", weight: 1,
    includeIf: ["飲酒", "晩酌", "アルコール"],
    excludeIf: ["断酒", "禁酒", "アルコール依存"],
    cond: "普段どおり〜やや不調（飲酒の影響）",
    soap: "前日に飲酒があった想定 口渇や寝つきへの影響をS/Oに 飲酒量への配慮をPに",
    vitals: "血圧をやや高め(+5〜15)、脈拍をやや高め(+5〜10)に" },
  { key: "heat", label: "暑さの影響", weight: 1, months: [6, 7, 8, 9],
    cond: "やや不調（暑さの影響）",
    soap: "暑さで汗をかきやすくだるさが出やすい想定 水分摂取の促しをPに",
    vitals: "体温をやや高め(+0.1〜0.3)、脈拍をやや高め(+3〜8)に" },
  { key: "cold", label: "冷えの影響", weight: 1, months: [11, 12, 1, 2, 3],
    cond: "やや不調（冷えの影響）",
    soap: "冷えで血圧が上がりやすくこわばりが出やすい想定 保温の声かけをPに",
    vitals: "血圧をやや高め(+5〜10)に" },
  { key: "symptom", label: "持病の症状がいつもよりやや強め", weight: 1,
    cond: "普段より症状がやや強い",
    soap: "療養状況にある主訴や症状が普段よりやや強い想定 該当症状の観察をOに 状態確認と経過観察をPに",
    vitals: "症状に応じて妥当な範囲で軽く変動させる" },
];

// 適合するシナリオを重み付きで1つ選ぶ。recentKeys(直近使用)は避ける（候補が尽きたら解除）。
// 適合性ガード(includeIf/excludeIf/months)は決して解除しない＝状態に合わないシナリオは絶対に出ない。
export function pickScenario(record, recentKeys) {
  const r = record || {};
  const text = String(r.care || "") + "／" + String(r.diagnosis || "");
  const month = extractMonth(r.visitDate);
  const fits = SCENARIOS.filter((s) => {
    if (s.includeIf && !s.includeIf.some((k) => text.includes(k))) return false;
    if (s.excludeIf && s.excludeIf.some((k) => text.includes(k))) return false;
    if (s.months && (month == null || !s.months.includes(month))) return false;
    return true;
  });
  if (!fits.length) return null; // calm は常に適合するため通常到達しない
  const recent = new Set(recentKeys || []);
  let pool = fits.filter((s) => !recent.has(s.key));
  if (!pool.length) pool = fits;
  const total = pool.reduce((a, s) => a + (s.weight || 1), 0);
  let t = Math.random() * total;
  for (const s of pool) {
    t -= s.weight || 1;
    if (t <= 0) return s;
  }
  return pool[pool.length - 1];
}

// ============================================================
// 本日の着眼点（S/Oの話題ローテーション）
// 話題候補＝その利用者の傷病名を機械的に分割したもの＋汎用観察軸。
// 疾患ごとの対応表は持たない（どんな疾患構成でもデータ駆動で機能する）。
// シナリオ同様、学習用モード(仮バイタル生成時)だけ使う。

// 汎用の観察軸（全利用者共通）
const FOCUS_GENERIC = ["睡眠の状態", "食事・水分のとり方", "活動量・生活リズム", "気分・表情", "全身状態と過ごし方"];

// 傷病名フィールドを分割して「〈病名〉のその日の状態」を話題候補にする
export function focusCandidates(record) {
  const names = String(record?.diagnosis || "")
    .split(/[\s、,・\/／]+/)
    .map((s) => s.trim())
    .filter((s) => s.length >= 2)
    .slice(0, 6); // 病名は上限6つまで話題化
  return [...new Set(names.map((n) => `${n}のその日の状態`))].concat(FOCUS_GENERIC);
}

// 候補から直近使用(recentLabels)を除外して無作為に1つ選ぶ（尽きたら除外を解く）
export function pickFocus(record, recentLabels) {
  const cands = focusCandidates(record);
  if (!cands.length) return null;
  const recent = new Set(recentLabels || []);
  let pool = cands.filter((l) => !recent.has(l));
  if (!pool.length) pool = cands;
  return pool[Math.floor(Math.random() * pool.length)];
}

// 訪問日文字列から月(1〜12)を取り出す。"2026/07/03"・"2026年7月3日"・"7月3日" いずれにも対応。
function extractMonth(visitDate) {
  const s = String(visitDate || "");
  let m = s.match(/\d{4}[/年.\-]\s*(\d{1,2})/);
  if (!m) m = s.match(/(\d{1,2})月/);
  const n = m ? parseInt(m[1], 10) : NaN;
  return n >= 1 && n <= 12 ? n : null;
}

