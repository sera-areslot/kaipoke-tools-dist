// 利用者情報ページに「取り込み」ボタンを出し、属性を userInternalId をキーに保存する。
// - 基本情報ページ(HNC090304): 氏名・性別・生年月日
// - ADL・看護ページ(HNC091704): 氏名・傷病名・療養状況（更新時はここで再取り込み）
//
// どちらのページかは、特徴的な要素の有無で判定する。

(function () {
  const uid = KRA.userInternalId();
  if (!uid) return; // 利用者ページでなければ何もしない

  const isAdl = !!document.querySelector("#sickName, #sickRestCondition");
  const isBasic = !isAdl && !!KRA.thToTd("性別");

  if (isAdl) {
    KRA.injectButton("▼ 傷病名・療養状況を取り込む", async () => {
      const diagnosis = KRA.valOf("#sickName");
      const care = KRA.valOf("#sickRestCondition");
      const name = KRA.pageUserName();
      if (!diagnosis && !care) { KRA.toast("傷病名・療養状況が空のようです", true); return; }
      await KRA.savePatientFields(uid, {
        name: name || undefined, diagnosis: diagnosis, care: care, adlAt: Date.now(),
      });
      KRA.toast("取り込みました（傷病名・療養状況）: " + (name || uid));
    });
  } else if (isBasic) {
    KRA.injectButton("▼ 基本情報を取り込む", async () => {
      const name = KRA.thToTd("氏名");
      const gender = KRA.thToTd("性別");
      const birth = KRA.thToTd("生年月日");
      if (!gender && !birth) { KRA.toast("性別・生年月日が見つかりません", true); return; }
      await KRA.savePatientFields(uid, {
        name: name || undefined, gender: gender, birth: birth, basicAt: Date.now(),
      });
      KRA.toast("取り込みました（性別・生年月日）: " + (name || uid));
    });
  }
})();
