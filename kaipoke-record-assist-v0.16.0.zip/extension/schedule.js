// カイポケ 月間スケジュール一覧ページ(画面ID HNC097802)の読み取り。
// 対象URL: https://r.kaipoke.biz/bizhnc/monthlyShiftsList/*
//
// この画面は「予定(左半分)」と「実績(右半分)」が横並びの表で、表示中の日付について
// 全職員ぶんの訪問(サービス行)が並ぶ。予定側のサービスは以下の onclick を持つ:
//   showHNC097807Edit('YYYYMM','<利用者内部ID>','<連番>','<記録ID>','<日>','<事業所>','HNC097802')
//     [0]=年月(YYYYMM) [1]=利用者の内部ID(=patientsキー) [2]=連番 [3]=記録ID [4]=日 ...
// 1訪問は同時刻のサービス行2本(連番01/02)で表現されることがあるため、
// (職員・日・利用者・開始時刻)で重複排除して「1訪問=1件」に畳む。
// 担当職員は、予定サービスのセル直後にある .tableInStaff セルから取得する(実績側の職員と混同しない)。

const SCH = {
  // 予定サービスの編集リンク。これがあれば月間スケジュール一覧ページとみなす。
  serviceLinkSelector: 'a[onclick*="showHNC097807Edit"]',
  timeRe: /(\d{1,2}:\d{2})\s*[～〜~]\s*(\d{1,2}:\d{2})/,
};

function isSchedulePage() {
  return !!document.querySelector(SCH.serviceLinkSelector);
}

function txt(el) {
  return el ? String(el.textContent || "").replace(/\s+/g, " ").trim() : "";
}

// 予定サービスのリンク1本から1サービス行を読む
function parseServiceLink(a) {
  const oc = a.getAttribute("onclick") || "";
  const m = oc.match(/showHNC097807Edit\(([^)]*)\)/);
  if (!m) return null;
  const args = m[1].split(",").map((s) => s.replace(/['"\s]/g, ""));
  const ym = args[0] || "";
  const uid = args[1] || "";
  const day = args[4] || "";
  if (!uid) return null;

  const serviceTd = a.closest("td");
  if (!serviceTd) return null;

  // 時刻("08:30 ～ 09:00")は同じサービスセル内のテキストから
  const area = serviceTd.querySelector(".service-detail-area") || serviceTd;
  const tm = txt(area).match(SCH.timeRe);
  const start = tm ? tm[1] : "";
  const end = tm ? tm[2] : "";

  // 担当職員(予定): サービスセルの直後の職員セル内 .tableInStaff から
  let staff = "";
  const staffTd = serviceTd.nextElementSibling;
  if (staffTd) {
    const sc =
      staffTd.querySelector(".tableInStaff .backgroundGray") ||
      staffTd.querySelector(".tableInStaff td") ||
      staffTd;
    staff = txt(sc);
  }

  // 利用者名(表示用フォールバック。基本は patients キャッシュの氏名を使う)
  const cellName = txt(serviceTd.previousElementSibling);

  return { ym, uid, day, start, end, staff, cellName, svc: txt(a) };
}

function extractSchedule() {
  const links = document.querySelectorAll(SCH.serviceLinkSelector);
  const lines = [];
  links.forEach((a) => {
    const v = parseServiceLink(a);
    if (v) lines.push(v);
  });

  // 連番01/02 等の重複を (職員・日・利用者・開始時刻) で畳む = 1訪問1件
  const seen = new Set();
  const visits = [];
  for (const v of lines) {
    const key = [v.staff, v.day, v.uid, v.start].join("|");
    if (seen.has(key)) continue;
    seen.add(key);
    visits.push(v);
  }

  const ym = visits.length ? visits[0].ym : "";
  return { ok: true, ym, serviceLines: lines.length, visits };
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type === "PING") {
    sendResponse({ ok: true, isSchedulePage: isSchedulePage() });
  } else if (msg?.type === "EXTRACT_SCHEDULE") {
    sendResponse(extractSchedule());
  }
});
