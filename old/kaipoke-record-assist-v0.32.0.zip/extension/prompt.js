// 観察記録(SOAP)生成プロンプト。
// 利用者の「療養状況」(看護師が記録した実際の状況)に基づいて整え、無い事実は作らない。
// 記録書Ⅱの観察記録欄(1つのテキスト欄)に入れるため、SOAPの4行テキストで出力する。
//
// ★文体・ルールの調整はこのファイルだけで完結する(拡張機能を再読み込みすれば反映)。

export const SYSTEM_PROMPT = [
  "あなたは訪問看護記録のSOAP欄を作成する補助ツールです。",
  "利用者の「療養状況」（看護師が記録した実際の状況）に基づき、S/O/A/P を簡潔に整えます。",
  "療養状況に書かれていない新しい事実（症状・所見・評価・数値）は作り出さないでください。",
  "ただし「本日の様子」として与えられた日常の出来事（睡眠・食事・外出・来訪など）は記載してかまいません。",
  "",
  "# 形式（重要）",
  "- 出力は次の4行のみ。前後に説明・コードフェンス・見出しを付けない。",
  "  S：…",
  "  O：…",
  "  A：…",
  "  P：…",
  "- 各行は体言止め・短い言い切りでまとめる。句読点（。、）は使わない。",
  "- 文章にせず要点を短く。1項目おおむね15〜25文字程度。",
  "- 例: 「S：夜中に何度か目覚めた」「O：表情やや硬く飲酒継続中」",
  "      「A：睡眠障害継続し活動性低下」「P：睡眠状況確認し傾聴実施」",
  "",
  "# 内容",
  "- S=利用者・家族の訴え / O=観察された状態 / A=評価 / P=対応・計画。",
  "- Sはその日の体調・生活に関する本人の言葉にする。療養状況にある同じ出来事・境遇",
  "  （例: 経済状況・家族の事情）を毎回Sにしない。「本日の様子」「本日の着眼点」の指定が無い場合のみ",
  "  直近の記録と話題も変える（指定がある場合は指定の話題を守り、言い回しだけ変える）。",
  "- 療養状況に該当が無い項目は「【　】」とする。",
  "- バイタル数値はSOAPに入れない（画面の数値欄にあるため）。",
  "- 「本日の様子」が与えられた場合、その出来事をS/Oに自然に反映し、A/Pも整合させる",
  "  （内容の着眼点を変えるための設定。療養状況と矛盾する記載にはしない）。",
  "- 「本日の様子」の出来事は、症状の改善・悪化の原因として結びつけない",
  "  （「来訪で症状が和らいだ」のような因果は作らず、その日の出来事として淡々と書く）。",
  "- 「本日の様子」に挙がっていない生活の話題（睡眠・食事・外出・来訪・飲酒・便通・暑さ寒さなど）は、",
  "  その日の記録に書かない・作らない（療養状況に由来する症状・所見の記載は従来どおりよい）。",
  "- 「本日の様子」は最大でも体調＋2話題。各行は15〜25文字と短いため、体調は主にA（必要ならSにも）へ、",
  "  話題はS/Oへ振り分け、選ばれた話題はすべて漏れなく簡潔に反映する。",
  "- 「本日の着眼点」が与えられた場合、S/Oはその話題を中心に組み立てる。傷病名にある症状の",
  "  その日の程度（良い/普段どおり/やや強い）を書くのはよい（新しい診断・急変・重大な所見は作らない）。",
  "- 「本日の様子」が平穏・良好系のときは、調子が良く落ち着いていることが伝わる記載にする",
  "  （慢性の訴えを毎回羅列しない）。",
  "- 症状の程度は「本日の調子」だけを基準に決める（唯一の判断基準）。軽めの日は",
  "  「昨日より痛みが和らいだ」「今日は楽」のような比較・前向き表現、やや不調の日はその旨を書く。",
  "  指定が前回と同じでも無理に変化を付けない（変えるのは言い回しだけ）。",
  "- A（評価）も「本日の調子」に連動させ、毎回「深刻・著しい支障」としない。",
  "  軽い日は「症状軽減傾向」「状態安定」、普段どおりの日は「経過観察継続」等を使い分ける。",
  "- P（計画）はその日の具体的な対応（傾聴・状態確認・助言・声かけ・次回の確認事項など）。",
  "  毎回「計画の見直し」「アプローチ再考」のような大きな話にしない。",
  "- 「調子が良い」「変わりない」だけの薄い記載にしない。何が・どの程度・どう過ごしたかを",
  "  一言分だけ具体化する（例:「気分の波なく午前は洗濯もできた」）。事実の捏造はしない。",
  "- 精神疾患（うつ等）の利用者では、体調の良し悪しだけでなく気分・意欲・不安・対人交流",
  "  など精神面の観察を中心に書く（身体の話題ばかりにしない）。",
  "- 客観的・簡潔で、訪問看護記録として自然な表現にする（誇張しない）。",
  "",
  "# 揺らぎ（毎月10件以上記載するため）",
  "- 「直近の記録」が与えられたら、それらと語彙・語順・文末表現を必ず変え、文言を繰り返さない。",
  "- 「本日の様子」「本日の着眼点」が与えられている場合、話題はその指定に従い、変えるのは言い回しだけにする。",
  "- 同じ事実でも、表現・言い回し・どの側面を先に書くかを変える。",
  "- ただし療養状況に無い事実は作らない（揺らすのは言い回しと「本日の様子」の範囲だけ）。",
].join("\n");

export function buildUserPrompt(record, supplement, priorSoaps, scenario, focus) {
  const r = record || {};
  const v = r.vitals || {};
  const bg = [];
  if (r.gender) bg.push("性別: " + r.gender);
  if (r.birth) bg.push("生年月日: " + r.birth);
  if (r.diagnosis) bg.push("傷病名: " + r.diagnosis);

  const vit = [];
  if (v.temp) vit.push("体温 " + v.temp);
  if (v.bpHigh || v.bpLow) vit.push("血圧 高" + (v.bpHigh || "—") + "/低" + (v.bpLow || "—"));
  if (v.pulse) vit.push("脈拍 " + v.pulse);

  const lines = [
    "## 背景（文脈のみ。ここから所見を作らない）",
    bg.join(" / ") || "（情報なし）",
    "",
    "## 療養状況（看護師が記録した実際の状況。SOAPはこれに基づく）",
    r.care || "（記載なし）",
    "",
    "## この訪問",
    "日付: " + (r.visitDate || "（不明）"),
  ];
  if (vit.length) lines.push("実測バイタル（参考）: " + vit.join(" / "));
  if (scenario) {
    lines.push(
      "",
      "## 本日の様子（この日の設定。複数の話題がある場合はすべて反映する。S/Oに自然に反映し、療養状況と矛盾させない。実測バイタルがある場合はその値と矛盾する身体状態も書かない）",
      scenario.label + "：" + scenario.soap,
      "本日の調子：" + (scenario.cond || "普段どおり")
    );
  }
  if (focus) {
    lines.push("", "## 本日の着眼点（S/Oの中心テーマ。傷病名・療養状況の範囲で）", focus);
  }
  if (supplement) lines.push("", "## 補足", supplement);

  if (priorSoaps && priorSoaps.length) {
    lines.push("", "## 直近の記録（これらと言い回しを変える。話題は「本日の様子」「本日の着眼点」の指定に従う）");
    priorSoaps.forEach((s, i) => lines.push("--- " + (i + 1) + " ---", s));
  }

  lines.push(
    "",
    "療養状況に基づき、指定の4行（S：/O：/A：/P：、体言止め・句読点なし）だけを出力してください。",
    "療養状況に無いことは作らず、該当が無い項目は【　】に。前回までと語彙・語順・文末表現を変え、文言を繰り返さないでください（指定された話題・着眼点は変えない）。"
  );
  return lines.join("\n");
}


// ============================================================
// 学習用: 演習問題づくり用のバイタル仮値生成。
// ★これは学習用の演習データ。実在の測定値ではなく、実際の提出・請求には使わない。
// ============================================================

export const SYSTEM_VITALS = [
  "あなたは看護学生向けの演習問題を作成する補助ツールです。",
  "架空の利用者の背景と療養状況から、その訪問日に観察されうる「現実的なバイタル",
  "（体温・血圧・脈拍）の仮の値」を1つ提案します。",
  "これは学習用の演習データであり、実在する人物の測定値ではありません。",
  "",
  "# ルール",
  "- 生理学的に妥当な範囲で、年齢・傷病名・療養状況に整合させる。",
  "  例: 高血圧があれば血圧は高め、安定した精神科の利用者なら概ね正常範囲、など。",
  "- 体温は℃の数値(例 36.7)、血圧は収縮期(高)と拡張期(低)に分ける、脈拍は回/分。",
  "- 脈拍の目安: 65歳以上は60〜80中心、65歳未満は65〜90中心（傷病名・状況により妥当な範囲で外れてよい）。",
  "- 血圧の下(拡張期)と脈拍を同じ値にしない。",
  "- 日ごとに自然なばらつきを持たせ、毎回まったく同じ値にはしない（特に体温は0.1〜0.3程度動かす）。",
  "- 「本日の様子」が与えられたら、その生理的影響を値に反映する。ただし「値の傾向」の指定がある項目は傾向を優先する。",
  "- 数値のみ。単位・記号・説明を付けない。",
  "",
  "# 出力",
  "- 次のJSONだけを出力する。前後に説明文・コードフェンスを付けない。",
  '  {"temp":"36.7","bpHigh":"122","bpLow":"78","pulse":"72"}',
].join("\n");

export function buildVitalsUserPrompt(record, bias, scenario) {
  const r = record || {};
  const lines = ["## 架空の利用者（演習用）"];
  if (r.gender) lines.push("性別: " + r.gender);
  if (r.birth) lines.push("生年月日: " + r.birth + "（年齢を推定）");
  if (r.diagnosis) lines.push("傷病名: " + r.diagnosis);
  if (r.care) lines.push("療養状況: " + r.care);
  lines.push("", "## 訪問日: " + (r.visitDate || "（不明）"));

  if (scenario) {
    lines.push("", "## 本日の様子（この日の設定。生理的影響を値に反映する）", scenario.label + "：" + scenario.vitals);
  }

  // 任意の傾向指定（低め/高め）。医学的整合を優先しつつ、その方向に寄せる。
  const b = bias || {};
  const dir = (v) => (v === "high" ? "高め" : v === "low" ? "低め" : "");
  const tend = [];
  if (dir(b.temp)) tend.push("体温は" + dir(b.temp));
  if (dir(b.bp)) tend.push("血圧は" + dir(b.bp));
  if (dir(b.pulse)) tend.push("脈拍は" + dir(b.pulse));
  if (tend.length) {
    lines.push(
      "",
      "## 値の傾向（できるだけこの方向に寄せる。ただし年齢・傷病名・療養状況と矛盾しない、生理学的に妥当な範囲で）",
      "- " + tend.join(" / ")
    );
  }

  lines.push("", "この日の現実的なバイタルの仮値を、指定のJSONで1つだけ出力してください。");
  return lines.join("\n");
}


// ============================================================
// 本日の様子（軸ごとの選択肢プール）
// 言い回しの揺らぎ(直近履歴)とは別に「その日の出来事」を決めるための設定。
// パネルの軸(体調・睡眠・食欲・活動・精神面・出来事)で選ばれた選択肢を
// composeScenario で1つに合成し、バイタル生成とSOAP生成の両方に渡して整合させる。
// 抽選はしない：選ばれたものがそのまま出て、選ばれなかった話題には言及しない。
// 仮バイタル生成時(＝バイタル欄が空の学習用モード)だけ使う。実測バイタル入力時は使わない。
//
//   includeIf: 療養状況＋傷病名にこの語が含まれるときだけ選択可能にする
//   excludeIf: この語が含まれていたら選択不可（状態に合わない話題を出さないための安全弁）
//   months:    この月のときだけ選択可能（訪問日から判定。月不明なら選択不可）
//   chip:      パネルのボタンに出す短い表示名（フル文は label をツールチップで見せる）
//   lock:      選択不可のときにホバーで出す簡潔な理由（ガード付きの選択肢に付ける）
//
// ★選択肢の追加・調整もこのファイルだけで完結する。
export const SCENARIOS = [
  { key: "calm", label: "特変なし（平穏な一日）", chip: "特変なし",
    cond: "落ち着いている（苦痛の訴えは軽い）",
    soap: "体調は落ち着いていて調子の良い一日 苦痛の訴えは軽めか無しで 穏やかに過ごす様子を記載",
    vitals: "普段どおりの安定した値" },
  { key: "good", label: "症状が軽く調子が良い", chip: "調子が良い",
    cond: "普段より症状が軽い（「昨日より痛みが和らいだ」等の比較表現を使ってよい）",
    soap: "痛みや不安など普段の症状が軽い想定 前向きな発言や活気をS/Oに反映",
    vitals: "安定した良好な値" },
  { key: "sleep_poor", label: "夜間に中途覚醒あり", chip: "中途覚醒",
    cond: "やや不調（睡眠不足の影響）",
    soap: "夜間の眠りが浅く中途覚醒があった想定 眠気や倦怠感をS/Oに反映",
    vitals: "睡眠不足の影響で血圧をやや高め(+5〜10)、脈拍をやや高め(+3〜8)に" },
  { key: "sleep_good", label: "よく眠れた", chip: "よく眠れた",
    cond: "普段より症状が軽め（休養がとれている）",
    soap: "睡眠が十分とれた想定 表情や活気の良さをS/Oに反映",
    vitals: "安定した落ち着いた値" },
  { key: "sleep_onset", label: "寝つきが悪い（入眠困難）", chip: "寝つき悪い", lock: "不眠等の記載時のみ選択可",
    includeIf: ["不眠", "入眠", "眠剤", "睡眠薬", "導入剤"],
    cond: "やや不調（入眠困難の影響）",
    soap: "布団に入っても寝つけない想定 入眠困難の訴えをSに 就寝前の過ごし方や生活リズムの確認をPに",
    vitals: "睡眠不足の影響で血圧をやや高め(+5〜10)に" },
  { key: "sleep_reversal", label: "昼夜逆転気味", chip: "昼夜逆転", lock: "不眠等の記載時のみ選択可",
    includeIf: ["昼夜逆転", "不眠"],
    cond: "やや不調（生活リズムの乱れ）",
    soap: "起床が昼近くになるなど生活リズムが乱れている想定 睡眠時間帯の乱れをS/Oに リズム調整の助言をPに",
    vitals: "大きな変動はない" },
  { key: "home", label: "終日在宅で静かに過ごした", chip: "終日在宅",
    cond: "普段どおり",
    soap: "外出なくテレビや読書などで静かに過ごした想定",
    vitals: "安静時の落ち着いた値 脈拍は低め寄り" },
  { key: "bowel", label: "便通の話題（便秘気味など）", chip: "便通の話題", lock: "便通の記載時のみ選択可",
    includeIf: ["便秘", "便通", "排便", "下剤", "緩下"],
    cond: "普段どおり",
    soap: "便秘気味や排便状況の訴えなど便通に関する話題をSに反映 水分摂取や腹部状態の確認をPに",
    vitals: "バイタルへの影響は小さい" },
  { key: "visitor", label: "家族・知人の来訪あり", chip: "来訪あり",
    cond: "普段どおり",
    soap: "家族や知人の来訪があった想定 会話の様子をS/Oに軽く触れる程度に（来訪を症状改善の理由にしない）",
    vitals: "普段どおりの落ち着いた値" },
  { key: "outing", label: "外出あり（散歩・買い物など）", chip: "外出あり", lock: "歩行可能な方のみ選択可",
    excludeIf: ["寝たきり", "終日臥床", "歩行不可", "歩行困難"],
    cond: "落ち着いている（外出できる程度に症状は軽い）",
    soap: "散歩や買い物などの外出があった想定 軽い疲労感や充実感を反映",
    vitals: "活動後のため脈拍をやや高め(+5〜10)に" },
  { key: "appetite_good", label: "食欲良好", chip: "食欲良好", lock: "経口摂取の方のみ選択可",
    excludeIf: ["経管", "胃ろう", "胃瘻", "経鼻"],
    cond: "普段どおり〜軽め",
    soap: "食事をおいしく摂れている想定 摂取状況をS/Oに反映",
    vitals: "安定した値" },
  { key: "appetite_low", label: "食欲やや低下", chip: "食欲低下", lock: "経口摂取の方のみ選択可",
    excludeIf: ["経管", "胃ろう", "胃瘻", "経鼻"],
    cond: "やや不調",
    soap: "食欲が普段よりやや落ちている想定 摂取量の減少をS/Oに 水分摂取の声かけをPに",
    vitals: "大きな変動はないが やや元気のない印象に整合させる" },
  { key: "hydration_low", label: "水分摂取が少なめ", chip: "水分少なめ", lock: "水分・脱水の記載時のみ選択可",
    includeIf: ["脱水", "水分", "利尿"],
    cond: "普段どおり",
    soap: "水分摂取が普段より少なめの想定 摂取状況をOに 水分摂取の促しをPに",
    vitals: "軽度の水分不足で脈拍をやや高め(+3〜5)にしてもよい" },
  { key: "alcohol", label: "前日に飲酒あり", chip: "飲酒あり", lock: "飲酒の記載時のみ選択可",
    includeIf: ["飲酒", "晩酌", "アルコール"],
    excludeIf: ["断酒", "禁酒", "アルコール依存"],
    cond: "普段どおり〜やや不調（飲酒の影響）",
    soap: "前日に飲酒があった想定 口渇や寝つきへの影響をS/Oに 飲酒量への配慮をPに",
    vitals: "血圧をやや高め(+5〜15)、脈拍をやや高め(+5〜10)に" },
  { key: "heat", label: "暑さの影響", chip: "暑さの影響", lock: "6〜9月のみ選択可", months: [6, 7, 8, 9],
    cond: "やや不調（暑さの影響）",
    soap: "暑さで汗をかきやすくだるさが出やすい想定 水分摂取の促しをPに",
    vitals: "体温をやや高め(+0.1〜0.3)、脈拍をやや高め(+3〜8)に" },
  { key: "cold", label: "冷えの影響", chip: "冷えの影響", lock: "11〜3月のみ選択可", months: [11, 12, 1, 2, 3],
    cond: "やや不調（冷えの影響）",
    soap: "冷えで血圧が上がりやすくこわばりが出やすい想定 保温の声かけをPに",
    vitals: "血圧をやや高め(+5〜10)に" },
  { key: "symptom", label: "持病の症状がいつもよりやや強め", chip: "症状やや強め",
    cond: "普段より症状がやや強い",
    soap: "療養状況にある主訴や症状が普段よりやや強い想定 該当症状の観察をOに 状態確認と経過観察をPに",
    vitals: "症状に応じて妥当な範囲で軽く変動させる" },
  // --- 精神科系（うつ・不安など）の専用シナリオ。該当の記載がある利用者だけ候補になる ---
  { key: "mood_low", label: "気分の落ち込みがやや強い", chip: "落ち込み", lock: "うつ等の記載時のみ選択可",
    includeIf: ["うつ", "抑うつ", "双極", "気分障害"],
    cond: "やや不調（気分の落ち込み）",
    soap: "気分の沈みや意欲の低下がいつもよりやや強い想定 落ち込みに関する本人の言葉をSに 表情の乏しさや口数の少なさをOに 傾聴と受容的な関わりをPに",
    vitals: "大きな変動はない" },
  { key: "motivation_low", label: "意欲が湧かず活動が億劫", chip: "意欲低下", lock: "精神疾患の記載時のみ選択可",
    includeIf: ["うつ", "抑うつ", "双極", "気分障害", "統合失調", "精神"],
    cond: "やや不調（意欲低下）",
    soap: "家事や身の回りのことが億劫で意欲が湧きにくい想定 活動量の低下をS/Oに 無理のない範囲での活動の提案をPに",
    vitals: "大きな変動はない" },
  { key: "diurnal", label: "朝方に気分が沈む（日内変動）", chip: "日内変動", lock: "うつ等の記載時のみ選択可",
    includeIf: ["うつ", "抑うつ", "双極"],
    cond: "やや不調（午前中心に気分が重い）",
    soap: "朝方は気分が重く午後にかけて少し持ち直す想定 時間帯による気分の変化をS/Oに 生活リズムの確認をPに",
    vitals: "大きな変動はない" },
  { key: "anxiety", label: "不安・焦りがやや強い", chip: "不安・焦り", lock: "不安・うつ等の記載時のみ選択可",
    includeIf: ["不安", "うつ", "抑うつ", "パニック", "精神"],
    cond: "やや不調（不安感）",
    soap: "不安や焦りがいつもよりやや強い想定 不安に関する訴えをSに 落ち着かない様子や表情をOに 傾聴と安心につながる声かけをPに",
    vitals: "緊張の影響で脈拍をやや高め(+3〜8)にしてもよい" },
];

// 本日の様子の軸。options は SCENARIOS の key を参照する。
// type:"seg" は「言及なし」を先頭に持つ単一選択、type:"chips" は複数トグル。
// counted:true の選択は「体調以外の内容は同時2つまで」の上限カウント対象
// （SOAPは各行15〜25文字の短文のため、話題を詰め込みすぎないための制限）。
export const AXES = [
  { id: "axisCond",     label: "体調",   type: "seg",   counted: false, options: ["good", "calm", "symptom"] },
  { id: "axisSleep",    label: "睡眠",   type: "seg",   counted: true,  options: ["sleep_good", "sleep_poor", "sleep_onset", "sleep_reversal"] },
  { id: "axisAppetite", label: "食欲",   type: "seg",   counted: true,  options: ["appetite_good", "appetite_low", "hydration_low"] },
  { id: "axisActivity", label: "活動",   type: "seg",   counted: true,  options: ["home", "outing"] },
  { id: "axisMental",   label: "精神面", type: "seg",   counted: true,  options: ["mood_low", "motivation_low", "diurnal", "anxiety"] },
  { id: "axisEvents",   label: "出来事", type: "chips", counted: true,  options: ["visitor", "alcohol", "bowel", "heat", "cold"] },
];

// 「本日の調子」の自動導出用分類。各選択肢自身の cond 文の趣旨に基づく。
// bad(不調系)が1つでもあれば「やや不調」、なければ fine(良好系)があれば「軽め」、どちらも無ければ「普段どおり」。
const COND_CLASS = {
  symptom: "bad", sleep_poor: "bad", sleep_onset: "bad", sleep_reversal: "bad",
  appetite_low: "bad", heat: "bad", cold: "bad",
  mood_low: "bad", motivation_low: "bad", diurnal: "bad", anxiety: "bad", alcohol: "bad",
  good: "fine", calm: "fine", sleep_good: "fine", appetite_good: "fine", outing: "fine",
  home: "neutral", visitor: "neutral", bowel: "neutral", hydration_low: "neutral",
};

// 利用者の状態に適合する選択肢(includeIf/excludeIf/months を満たすもの)を返す。
// パネルのボタン活性/非活性表示にも使う。
export function eligibleScenarios(record) {
  const r = record || {};
  const text = String(r.care || "") + "／" + String(r.diagnosis || "");
  const month = extractMonth(r.visitDate);
  return SCENARIOS.filter((s) => {
    if (s.includeIf && !s.includeIf.some((k) => text.includes(k))) return false;
    if (s.excludeIf && s.excludeIf.some((k) => text.includes(k))) return false;
    if (s.months && (month == null || !s.months.includes(month))) return false;
    return true;
  });
}

// パネルで選択された key 群から「本日の様子」を1つに合成する。抽選はしない。
// 適合性ガード(includeIf/excludeIf/months)は決して解除しない＝不適合な key は黙って落とす。
// 何も選択されていなければ null（＝本日の様子なし。生活の話題には言及しない）。
export function composeScenario(record, selectedKeys) {
  const ok = new Set(eligibleScenarios(record).map((s) => s.key));
  const seen = new Set();
  const items = (Array.isArray(selectedKeys) ? selectedKeys : [])
    .map((k) => SCENARIOS.find((s) => s.key === String(k)))
    .filter((s) => s && ok.has(s.key) && !seen.has(s.key) && seen.add(s.key));
  if (!items.length) return null;
  const cls = items.map((s) => COND_CLASS[s.key] || "neutral");
  const cond = cls.includes("bad") ? "やや不調"
    : cls.includes("fine") ? "軽め（落ち着いている）"
    : "普段どおり";
  return {
    keys: items.map((s) => s.key),
    label: items.map((s) => s.chip || s.label).join("＋"),
    cond,
    soap: items.map((s) => s.soap).join(" ／ "),
    vitals: items.map((s) => s.vitals).join(" ／ "),
  };
}

// ============================================================
// 本日の着眼点（S/Oの中心テーマ）
// 話題候補＝その利用者の傷病名を機械的に分割したもの＋汎用観察軸。
// 疾患ごとの対応表は持たない（どんな疾患構成でもデータ駆動で機能する）。
// パネルで単一選択する。選択が無ければ着眼点なし（抽選はしない）。
// 本日の様子と同様、学習用モード(仮バイタル生成時)だけ使う。

// 汎用の観察軸（全利用者共通）
const FOCUS_GENERIC = ["睡眠の状態", "食事・水分のとり方", "活動量・生活リズム", "気分・表情", "全身状態と過ごし方"];

// 精神科系（うつ・不安など）の観察軸。該当の記載がある利用者だけ候補に加える
const FOCUS_MENTAL = ["気分の落ち込みや波の程度", "意欲・興味の持ち方", "不安や焦りの程度", "対人交流・会話の様子"];
const MENTAL_RE = /うつ|抑うつ|双極|気分障害|不安|パニック|統合失調|精神/;

// 傷病名フィールドを分割して「〈病名〉のその日の状態」を話題候補にする
export function focusCandidates(record) {
  const names = String(record?.diagnosis || "")
    .split(/[\s、,・\/／]+/)
    .map((s) => s.trim())
    .filter((s) => s.length >= 2)
    .slice(0, 6); // 病名は上限6つまで話題化
  const out = [...new Set(names.map((n) => `${n}のその日の状態`))].concat(FOCUS_GENERIC);
  const text = String(record?.diagnosis || "") + "／" + String(record?.care || "");
  if (MENTAL_RE.test(text)) out.push(...FOCUS_MENTAL);
  return out;
}

// 訪問日文字列から月(1〜12)を取り出す。"2026/07/03"・"2026年7月3日"・"7月3日" いずれにも対応。
function extractMonth(visitDate) {
  const s = String(visitDate || "");
  let m = s.match(/\d{4}[/年.\-]\s*(\d{1,2})/);
  if (!m) m = s.match(/(\d{1,2})月/);
  const n = m ? parseInt(m[1], 10) : NaN;
  return n >= 1 && n <= 12 ? n : null;
}

